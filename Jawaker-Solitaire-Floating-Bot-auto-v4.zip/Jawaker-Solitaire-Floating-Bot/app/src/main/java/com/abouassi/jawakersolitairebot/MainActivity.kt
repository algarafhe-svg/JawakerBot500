package com.abouassi.jawakersolitairebot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
    private val projectionRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(11, 30, 51))
        }
        val title = TextView(this).apply {
            text = "Jawaker Solitaire\nFloating Bot"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "الحالة: جاهز — امنح الصلاحيات المطلوبة"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(actionButton("1. السماح بالظهور فوق التطبيقات") { requestOverlayPermission() })
        root.addView(actionButton("2. تفعيل خدمة إمكانية الوصول") { openAccessibilitySettings() })
        root.addView(actionButton("3. بدء التقاط الشاشة وإظهار اللوحة") { requestScreenCapture() })
        root.addView(actionButton("إيقاف الخدمات") {
            stopService(Intent(this, FloatingBotService::class.java))
            stopService(Intent(this, ScreenCaptureService::class.java))
            status.text = "الحالة: تم طلب إيقاف الخدمات"
        })
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 10 }
        }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } else status.text = "الحالة: صلاحية النافذة العائمة مفعّلة"
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestScreenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "فعّل صلاحية الظهور فوق التطبيقات أولاً"
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Deprecated by Android, retained for API 29 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            startService(Intent(this, FloatingBotService::class.java))
            status.text = "الحالة: التقاط الشاشة واللوحة العائمة يعملان"
        } else status.text = "الحالة: لم تتم الموافقة على التقاط الشاشة"
    }
}
