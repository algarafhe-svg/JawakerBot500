package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.media.Image
import kotlin.math.abs

/** Reads the current board and returns one legal tableau/waste move or a stock tap. */
object BoardAnalyzer {
    data class Move(
        val fromX: Float,
        val fromY: Float,
        val toX: Float,
        val toY: Float,
        val durationMs: Long = 430L,
        val isTap: Boolean = false
    )

    data class Analysis(val status: String, val proposedMove: Move? = null)

    private const val REF_W = 720f
    private const val REF_H = 1640f
    private const val FIRST_CARD_Y = 470f

    fun analyze(image: Image, width: Int, height: Int): Analysis {
        val bitmap = try { CardVision.imageToBitmap(image) }
        catch (_: Exception) { return Analysis("تعذر تحويل لقطة الشاشة") }
        return try { analyze(bitmap) } finally { bitmap.recycle() }
    }

    fun analyze(bitmap: Bitmap): Analysis {
        val board = try { CardVision.analyze(bitmap) }
        catch (e: Exception) {
            return Analysis("خطأ قراءة اللوحة: ${e.message ?: "غير معروف"}")
        }
        val sx = bitmap.width / REF_W
        val sy = bitmap.height / REF_H
        val cols = board.columns
        if (cols.size != 7) return Analysis("لم أتعرف على الأعمدة السبعة. ${board.diagnostics}")
        val detectedTableauCards = cols.sumOf { it.visibleCards.size }
        if (detectedTableauCards < 4) {
            return Analysis("قراءة الكروت غير كافية ($detectedTableauCards فقط)؛ لن أنقر عشوائياً. ${board.diagnostics}")
        }

        data class Candidate(val move: Move, val score: Int, val label: String)
        val candidates = mutableListOf<Candidate>()

        // Move any valid descending alternating-colour suffix between tableau columns.
        for (from in cols.indices) {
            val source = cols[from].visibleCards
            if (source.isEmpty()) continue
            for (start in source.indices) {
                val suffix = source.drop(start)
                if (!isValidSequence(suffix)) continue
                val moving = suffix.first()
                for (to in cols.indices) {
                    if (to == from) continue
                    val targetCards = cols[to].visibleCards
                    val target = targetCards.lastOrNull()
                    val legal = if (target == null) moving.rank == 13
                        else moving.suitColor != target.suitColor && moving.rank == target.rank - 1
                    if (!legal) continue
                    val sourceX = CardVisionCenter.column(from) * sx
                    val targetX = CardVisionCenter.column(to) * sx
                    val sourceY = (moving.topY + 38f * sy).coerceIn(0f, bitmap.height.toFloat())
                    val targetTop = target?.topY ?: FIRST_CARD_Y * sy
                    val targetY = (targetTop + 38f * sy).coerceAtMost(bitmap.height.toFloat())
                    val revealBonus = if (start == 0 && cols[from].hiddenCount > 0) 35 else 0
                    val score = 50 + revealBonus + if (target == null) 10 else 0
                    candidates += Candidate(Move(sourceX, sourceY, targetX, targetY), score,
                        "${rankName(moving.rank)} من العمود ${from + 1} إلى ${to + 1}")
                }
            }
        }

        // The waste card can be placed on a legal tableau column.
        board.waste?.let { waste ->
            for (to in cols.indices) {
                val target = cols[to].visibleCards.lastOrNull()
                val legal = if (target == null) waste.rank == 13
                    else waste.suitColor != target.suitColor && waste.rank == target.rank - 1
                if (legal) {
                    val targetY = (target?.topY ?: FIRST_CARD_Y * sy) + 38f * sy
                    candidates += Candidate(
                        Move(535f * sx, 365f * sy, CardVisionCenter.column(to) * sx, targetY),
                        90, "نقل ${rankName(waste.rank)} من المخزون المفتوح إلى العمود ${to + 1}"
                    )
                }
            }
        }

        val best = candidates.maxByOrNull { it.score }
        if (best != null) return Analysis("${board.diagnostics} — حركة: ${best.label}", best.move)

        if (board.stockHasCard) {
            return Analysis("${board.diagnostics} — لا توجد حركة؛ سحب من المخزون", 
                Move(655f * sx, 365f * sy, 655f * sx, 365f * sy, 80L, true))
        }
        return Analysis("${board.diagnostics} — لا توجد حركة والمخزون يبدو فارغاً")
    }

    private fun isValidSequence(cards: List<CardVision.CardObservation>): Boolean {
        if (cards.isEmpty()) return false
        for (i in 0 until cards.lastIndex) {
            val upper = cards[i]
            val lower = cards[i + 1]
            val verticalGap = abs(lower.topY - upper.topY)
            if (verticalGap > 105f || verticalGap < 18f ||
                upper.suitColor == lower.suitColor || upper.rank != lower.rank + 1) return false
        }
        return true
    }

    private fun rankName(rank: Int): String = when (rank) {
        1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> rank.toString()
    }

    private object CardVisionCenter {
        private val centers = floatArrayOf(65f, 165f, 265f, 365f, 465f, 565f, 665f)
        fun column(index: Int): Float = centers[index]
    }
}
