package com.abouassi.jawakersolitairebot

import android.app.Service
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBotService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var stateText: TextView
    private var running = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val message = intent?.getStringExtra(ScreenCaptureService.EXTRA_STATUS)
            if (!message.isNullOrBlank() && ::stateText.isInitialized) stateText.text = message
        }
    }

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter(ScreenCaptureService.ACTION_ANALYSIS_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(statusReceiver, filter)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xEE102A43.toInt())
        }
        val header = TextView(this).apply {
            text = "JAWAKER BOT     ⋮"
            textSize = 13f
            setTextColor(0xFFFFD166.toInt())
            setPadding(6, 4, 6, 8)
        }
        stateText = TextView(this).apply {
            text = "متوقف"
            textSize = 12f
            setTextColor(-1)
            setPadding(6, 2, 6, 8)
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val toggle = Button(this).apply {
            text = "تشغيل"
            isAllCaps = false
            setOnClickListener {
                running = !running
                text = if (running) "إيقاف مؤقت" else "تشغيل"
                stateText.text = if (running) "بدأ تحليل الكروت وتنفيذ الحركات" else "متوقف"
                sendBroadcast(Intent(ScreenCaptureService.ACTION_SET_RUNNING).setPackage(packageName)
                    .putExtra(ScreenCaptureService.EXTRA_RUNNING, running))
            }
        }
        val close = Button(this).apply {
            text = "X"
            isAllCaps = false
            setOnClickListener { stopSelf() }
        }
        controls.addView(toggle)
        controls.addView(close)
        layout.addView(header)
        layout.addView(stateText)
        layout.addView(controls)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val density = metrics.density
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12f * density).toInt()
            // Start near the bottom of the 720x1640 game screen, clear of
            // the stock/foundation row and tableau. The header remains draggable.
            y = (metrics.heightPixels - 270f * density).toInt().coerceAtLeast(0)
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(layout, params)
                        return true
                    }
                }
                return false
            }
        })
        panel = layout
        windowManager.addView(layout, params)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(statusReceiver) }
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        super.onDestroy()
    }
}
