package com.abouassi.jawakersolitairebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.util.DisplayMetrics
import android.view.WindowManager

class BotAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun tap(x: Float, y: Float, durationMs: Long = 90L, callback: ((Boolean) -> Unit)? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            callback?.invoke(false); return
        }
        val path = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { callback?.invoke(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { callback?.invoke(false) }
        }, null)
    }

    /** Two distinct short taps with an 80ms gap; reserved for Foundation moves. */
    fun doubleTap(x: Float, y: Float, intervalMs: Long = 80L,
                  callback: ((Boolean) -> Unit)? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            callback?.invoke(false); return
        }
        tap(x, y, 55L) { firstOk ->
            if (!firstOk) {
                callback?.invoke(false)
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    tap(x, y, 55L, callback)
                }, intervalMs)
            }
        }
    }

    fun drag(fromX: Float, fromY: Float, toX: Float, toY: Float, durationMs: Long = 600L,
             callback: ((Boolean) -> Unit)? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            callback?.invoke(false); return
        }
        val path = Path().apply {
            moveTo(fromX, fromY)
            lineTo(toX, toY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    companion object {
        @Volatile private var instance: BotAccessibilityService? = null

        fun dispatchDrag(x1: Float, y1: Float, x2: Float, y2: Float,
                         durationMs: Long = 600L, callback: ((Boolean) -> Unit)? = null) {
            val service = instance
            if (service == null) callback?.invoke(false)
            else service.drag(x1, y1, x2, y2, durationMs, callback)
        }

        fun dispatchTap(x: Float, y: Float, durationMs: Long = 90L,
                        callback: ((Boolean) -> Unit)? = null) {
            val service = instance
            if (service == null) callback?.invoke(false) else service.tap(x, y, durationMs, callback)
        }

        fun dispatchDoubleTap(x: Float, y: Float, intervalMs: Long = 80L,
                             callback: ((Boolean) -> Unit)? = null) {
            val service = instance
            if (service == null) callback?.invoke(false)
            else service.doubleTap(x, y, intervalMs, callback)
        }

        fun isEnabled(): Boolean = instance != null
    }
}
