package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.media.Image
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.roundToInt

/** Chooses legal Klondike moves from a 720x1640 board observation. */
object BoardAnalyzer {
    data class Move(
        val fromX: Float,
        val fromY: Float,
        val toX: Float,
        val toY: Float,
        val durationMs: Long = DEFAULT_DRAG_MS,
        val isTap: Boolean = false,
        val isDoubleTap: Boolean = false
    )

    data class Analysis(val status: String, val proposedMove: Move? = null)

    private data class Candidate(val move: Move, val score: Int, val label: String)
    private data class PendingDrag(val key: String, val boardBefore: String)

    private const val REF_W = 720f
    private const val REF_H = 1640f
    private const val WASTE_X = 565f
    private const val WASTE_Y = 490f
    private const val STOCK_X = 655f
    private const val STOCK_Y = 490f
    private const val DEFAULT_DRAG_MS = 770L
    private const val MOVE_HISTORY_LIMIT = 60
    private const val FAILED_MOVE_COOLDOWN_CYCLES = 10L
    private const val TABLEAU_MIN_Y = 580f
    private const val TABLEAU_MAX_Y = 1250f
    private const val EMPTY_COLUMN_DROP_Y = 620f

    // Explicit left-to-right mapping, as calibrated for the requested RTL screen.
    private val columnCenters = floatArrayOf(68f, 166f, 264f, 362f, 460f, 558f, 655f)
    private val recentMoveKeys = ArrayDeque<String>()
    private val recentMoveSet = mutableSetOf<String>()
    private val failedMoveUntilCycle = mutableMapOf<String, Long>()
    private var pendingDrag: PendingDrag? = null
    private var analysisCycle = 0L
    private var stockDrawCount = 0

    @Synchronized
    fun resetMemory() {
        recentMoveKeys.clear()
        recentMoveSet.clear()
        failedMoveUntilCycle.clear()
        pendingDrag = null
        analysisCycle = 0L
        stockDrawCount = 0
    }

    fun analyze(image: Image, width: Int, height: Int): Analysis {
        val bitmap = try {
            CardVision.imageToBitmap(image)
        } catch (_: Exception) {
            return Analysis("تعذر تحويل لقطة الشاشة")
        }
        return try {
            analyze(bitmap)
        } finally {
            bitmap.recycle()
        }
    }

    @Synchronized
    fun analyze(bitmap: Bitmap): Analysis {
        val board = try {
            CardVision.analyze(bitmap)
        } catch (e: Exception) {
            return Analysis("خطأ قراءة اللوحة: ${e.message ?: "غير معروف"}")
        }

        if (board.columns.size != 7) {
            return Analysis("لم أتعرف على الأعمدة السبعة. ${board.diagnostics}")
        }

        // Convert reference coordinates to bitmap pixels exactly once. Card topY
        // values from CardVision are already absolute bitmap pixels and are never rescaled.
        val sx = bitmap.width / REF_W
        val sy = bitmap.height / REF_H
        analysisCycle++
        val boardState = boardSignature(board)
        evaluatePreviousDrag(boardState)
        failedMoveUntilCycle.entries.removeAll { (_, until) -> analysisCycle >= until }

        val detectedTableauCards = board.columns.sumOf { it.visibleCards.size }
        if (detectedTableauCards == 0 && board.waste == null &&
            board.columns.none { !it.isCompletelyEmpty }) {
            return Analysis("لم أتعرف على أوراق الأعمدة أو الكومة؛ ${board.diagnostics}")
        }

        val foundationCandidates = mutableListOf<Candidate>()
        val tableauCandidates = mutableListOf<Candidate>()
        val wasteCandidates = mutableListOf<Candidate>()

        // A) Priority 1: any exposed tableau or free waste card that can advance
        // its own foundation. Exact suit identification is mandatory.
        for (from in board.columns.indices) {
            val card = board.columns[from].visibleCards.lastOrNull() ?: continue
            val suit = card.suit ?: continue
            val currentRank = board.foundationRanks[suit] ?: 0
            if (SolitaireEngine.canMoveToFoundation(card.rank, currentRank)) {
                val x = columnCenters[from] * sx
                val y = clampTableauY(card.topY + 42f * sy, sy)
                foundationCandidates += Candidate(
                    Move(x, y, x, y, 55L, isDoubleTap = true),
                    500,
                    "رفع ${rankName(card.rank)}${suitSymbol(suit)} من العمود ${from + 1} إلى الأساس"
                )
            }
        }

        board.waste?.let { card ->
            val suit = card.suit
            if (suit != null) {
                val currentRank = board.foundationRanks[suit] ?: 0
                if (SolitaireEngine.canMoveToFoundation(card.rank, currentRank)) {
                    val x = WASTE_X * sx
                    val y = WASTE_Y * sy
                    foundationCandidates += Candidate(
                        Move(x, y, x, y, 55L, isDoubleTap = true),
                        510,
                        "رفع ${rankName(card.rank)}${suitSymbol(suit)} من الورقة الحرة إلى الأساس"
                    )
                }
            }
        }

        val bestFoundation = foundationCandidates
            .sortedByDescending { it.score }
            .firstOrNull { !isMoveSuppressed(it.move) }
        if (bestFoundation != null) {
            rememberMove(bestFoundation.move)
            pendingDrag = null
            stockDrawCount = 0
            return Analysis("قرار: ${bestFoundation.label}؛ ${board.diagnostics}", bestFoundation.move)
        }

        // B) Tableau moves are allowed only when they reveal a face-down card,
        // or when a genuine King is placed into a pixel-confirmed empty column.
        for (from in board.columns.indices) {
            val sourceColumn = board.columns[from]
            val source = sourceColumn.visibleCards
            if (source.isEmpty()) continue

            for (start in source.indices) {
                val suffix = source.drop(start)
                if (!isValidSequence(suffix, sy)) continue
                val moving = suffix.first()
                val revealsHidden = start == 0 && sourceColumn.hiddenCount > 0

                for (to in board.columns.indices) {
                    if (to == from) continue
                    val targetColumn = board.columns[to]
                    val targetCards = targetColumn.visibleCards
                    val target = targetCards.lastOrNull()
                    val targetIsCompletelyEmpty = targetColumn.isCompletelyEmpty
                    val kingToEmpty = moving.rank == 13 && targetIsCompletelyEmpty
                    if (!revealsHidden && !kingToEmpty) continue

                    val legal = SolitaireEngine.canStackOnTableau(
                        moving.rank, moving.suitColor,
                        target?.rank, target?.suitColor,
                        targetIsCompletelyEmpty
                    )
                    if (!legal) continue

                    val sourceX = columnCenters[from] * sx
                    val targetX = columnCenters[to] * sx
                    val sourceY = clampTableauY(moving.topY + 24f * sy, sy)
                    val targetY = if (targetIsCompletelyEmpty) EMPTY_COLUMN_DROP_Y * sy
                    else clampTableauY(target!!.topY + 42f * sy, sy)

                    val score = when {
                        revealsHidden -> 400
                        kingToEmpty -> 320
                        else -> 0
                    }
                    tableauCandidates += Candidate(
                        Move(sourceX, sourceY, targetX, targetY, DEFAULT_DRAG_MS),
                        score,
                        "${rankName(moving.rank)} من العمود ${from + 1} إلى ${to + 1}" +
                            if (revealsHidden) " لكشف ورقة مخفية" else " لوضع الشايب في عمود فارغ مؤكّد"
                    )
                }
            }
        }

        val bestTableau = tableauCandidates
            .sortedByDescending { it.score }
            .firstOrNull { !isMoveSuppressed(it.move) }
        if (bestTableau != null) {
            rememberMove(bestTableau.move)
            pendingDrag = PendingDrag(moveKey(bestTableau.move), boardState)
            stockDrawCount = 0
            return Analysis("قرار: ${bestTableau.label}؛ ${board.diagnostics}", bestTableau.move)
        }

        // C) Move the currently free rightmost Draw-3 waste card onto a legal column.
        board.waste?.let { waste ->
            for (to in board.columns.indices) {
                val targetColumn = board.columns[to]
                val target = targetColumn.visibleCards.lastOrNull()
                val targetIsCompletelyEmpty = targetColumn.isCompletelyEmpty
                val legal = SolitaireEngine.canStackOnTableau(
                    waste.rank, waste.suitColor,
                    target?.rank, target?.suitColor,
                    targetIsCompletelyEmpty
                )
                if (!legal) continue

                val targetY = if (targetIsCompletelyEmpty) EMPTY_COLUMN_DROP_Y * sy
                else clampTableauY(target!!.topY + 42f * sy, sy)
                wasteCandidates += Candidate(
                    Move(
                        WASTE_X * sx, WASTE_Y * sy,
                        columnCenters[to] * sx, targetY,
                        DEFAULT_DRAG_MS
                    ),
                    200,
                    "نقل ${rankName(waste.rank)} من الورقة الحرة إلى العمود ${to + 1}"
                )
            }
        }

        val bestWaste = wasteCandidates
            .sortedByDescending { it.score }
            .firstOrNull { !isMoveSuppressed(it.move) }
        if (bestWaste != null) {
            rememberMove(bestWaste.move)
            pendingDrag = PendingDrag(moveKey(bestWaste.move), boardState)
            stockDrawCount = 0
            return Analysis("قرار: ${bestWaste.label}؛ ${board.diagnostics}", bestWaste.move)
        }

        // D) Only when no legal foundation/tableau/waste placement remains, draw stock.
        if (board.stockHasCard) {
            stockDrawCount++
            pendingDrag = null
            val x = STOCK_X * sx
            val y = STOCK_Y * sy
            return Analysis(
                "قرار: نقر كومة السحب ($stockDrawCount)؛ انتظار استقرار Draw-3؛ ${board.diagnostics}",
                Move(x, y, x, y, 90L, isTap = true)
            )
        }

        pendingDrag = null
        return Analysis("لا توجد حركة قانونية ظاهرة ولا توجد أوراق في كومة السحب؛ ${board.diagnostics}")
    }

    /** A drag is failed only if the next analyzed board has the same card layout. */
    private fun evaluatePreviousDrag(currentBoardSignature: String) {
        val pending = pendingDrag ?: return
        pendingDrag = null
        if (currentBoardSignature == pending.boardBefore) {
            failedMoveUntilCycle[pending.key] = analysisCycle + FAILED_MOVE_COOLDOWN_CYCLES
        }
    }

    private fun boardSignature(board: CardVision.BoardObservation): String {
        val columnsPart = board.columns.map { column ->
            val cards = column.visibleCards.joinToString(",") { card ->
                val yBucket = (card.topY / 24f).roundToInt()
                "${card.rank}-${card.suitColor}-${card.suit ?: "?"}-$yBucket"
            }
            "$cards|h=${column.hiddenCount}|f=${column.hasCardFace}|b=${column.hasHiddenCardBack}|g=${column.greenBackgroundConfirmed}"
        }.joinToString(";")
        val foundationsPart = SolitaireEngine.Suit.values().joinToString(",") { suit ->
            "${suit.name}:${board.foundationRanks[suit] ?: 0}"
        }
        val wastePart = board.waste?.let {
            "${it.rank}-${it.suitColor}-${it.suit ?: "?"}"
        } ?: "none"
        return "$columnsPart#$foundationsPart#$wastePart#stock=${board.stockHasCard}"
    }

    private fun isMoveSuppressed(move: Move): Boolean {
        if (isRecentlyRepeated(move)) return true
        val blockedUntil = failedMoveUntilCycle[moveKey(move)] ?: return false
        return analysisCycle < blockedUntil
    }

    @Synchronized
    private fun moveKey(move: Move): String = listOf(
        move.fromX.roundToInt(), move.fromY.roundToInt(),
        move.toX.roundToInt(), move.toY.roundToInt(),
        move.isTap, move.isDoubleTap
    ).joinToString(":")

    @Synchronized
    private fun isRecentlyRepeated(move: Move): Boolean {
        if (move.isTap || move.isDoubleTap) return false
        val reverse = listOf(
            move.toX.roundToInt(), move.toY.roundToInt(),
            move.fromX.roundToInt(), move.fromY.roundToInt(),
            move.isTap, move.isDoubleTap
        ).joinToString(":")
        return reverse in recentMoveSet
    }

    @Synchronized
    private fun rememberMove(move: Move) {
        val key = moveKey(move)
        recentMoveKeys.addLast(key)
        recentMoveSet.add(key)
        while (recentMoveKeys.size > MOVE_HISTORY_LIMIT) {
            val old = recentMoveKeys.removeFirst()
            if (old !in recentMoveKeys) recentMoveSet.remove(old)
        }
    }

    private fun isValidSequence(
        cards: List<CardVision.CardObservation>,
        sy: Float
    ): Boolean {
        if (cards.isEmpty()) return false
        for (i in 0 until cards.lastIndex) {
            val upper = cards[i]
            val lower = cards[i + 1]
            val verticalGap = abs(lower.topY - upper.topY)
            if (verticalGap > 115f * sy || verticalGap < 16f * sy ||
                upper.suitColor == lower.suitColor || upper.rank != lower.rank + 1
            ) return false
        }
        return true
    }

    private fun clampTableauY(valuePx: Float, sy: Float): Float =
        valuePx.coerceIn(TABLEAU_MIN_Y * sy, TABLEAU_MAX_Y * sy)

    private fun rankName(rank: Int): String = when (rank) {
        1 -> "A"
        11 -> "J"
        12 -> "Q"
        13 -> "K"
        else -> rank.toString()
    }

    private fun suitSymbol(suit: SolitaireEngine.Suit): String = when (suit) {
        SolitaireEngine.Suit.HEARTS -> "♥"
        SolitaireEngine.Suit.DIAMONDS -> "♦"
        SolitaireEngine.Suit.SPADES -> "♠"
        SolitaireEngine.Suit.CLUBS -> "♣"
    }
}
