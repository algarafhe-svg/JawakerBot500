package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** Jawaker board reader calibrated to 720x1640 reference coordinates. */
object CardVision {
    data class CardObservation(
        val rank: Int,
        val suitColor: SolitaireEngine.SuitColor,
        val suit: SolitaireEngine.Suit?,
        val confidence: Float,
        /** Bounds are in bitmap pixels, not reference-screen coordinates. */
        val bounds: Rect,
        /** Absolute bitmap-pixel Y coordinate. */
        val topY: Float,
        /** Absolute bitmap-pixel X coordinate. */
        val centerX: Float
    )

    data class ColumnObservation(
        val visibleCards: List<CardObservation>,
        val hiddenCount: Int,
        val hasCardFace: Boolean = false,
        val hasHiddenCardBack: Boolean = false,
        val greenBackgroundConfirmed: Boolean = false
    ) {
        /** A King target must be a verified green-felt column, not an OCR blank. */
        val isCompletelyEmpty: Boolean
            get() = visibleCards.isEmpty() && hiddenCount == 0 &&
                !hasCardFace && !hasHiddenCardBack && greenBackgroundConfirmed
    }

    data class BoardObservation(
        val columns: List<ColumnObservation>,
        val foundationRanks: Map<SolitaireEngine.Suit, Int>,
        val foundationSlots: Map<SolitaireEngine.Suit, Int>,
        val occupiedFoundationSlots: Set<Int>,
        val waste: CardObservation?,
        val stockHasCard: Boolean,
        val diagnostics: String
    )

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // All coordinates below are in the 720x1640 reference coordinate system.
    private val columnCenters = floatArrayOf(68f, 166f, 264f, 362f, 460f, 558f, 655f)
    private val foundationCenters = floatArrayOf(68f, 166f, 264f, 362f)
    private const val TABLEAU_FIRST_Y = 580f
    private const val TABLEAU_LAST_Y = 1250f
    private const val COLUMN_OCCUPANCY_CHECK_BOTTOM_Y = 750f
    private const val WASTE_X = 565f
    private const val TOP_ROW_Y = 490f

    fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + max(0, rowPadding / pixelStride)
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also {
            padded.recycle()
        }
    }

    fun analyze(bitmap: Bitmap): BoardObservation {
        require(bitmap.width > 0 && bitmap.height > 0) { "صورة الشاشة فارغة" }
        val sx = bitmap.width / 720f
        val sy = bitmap.height / 1640f
        val columns = MutableList(7) { mutableListOf<CardObservation>() }
        val ocrCounts = IntArray(7)
        val cardFaceDetected = BooleanArray(7)
        val hiddenBackDetected = BooleanArray(7)
        val greenBackgroundConfirmed = BooleanArray(7)

        for (columnIndex in columnCenters.indices) {
            val referenceCenter = columnCenters[columnIndex]
            val centerPx = referenceCenter * sx
            val colRect = scaledRect(
                bitmap, referenceCenter - 44f, TABLEAU_FIRST_Y,
                referenceCenter + 44f, TABLEAU_LAST_Y, sx, sy
            )

            // Independent occupancy check: never infer an empty column from OCR alone.
            val occupancyRect = scaledRect(
                bitmap, referenceCenter - 44f, TABLEAU_FIRST_Y,
                referenceCenter + 44f, COLUMN_OCCUPANCY_CHECK_BOTTOM_Y, sx, sy
            )
            hiddenBackDetected[columnIndex] = detectRedBack(bitmap, occupancyRect)
            cardFaceDetected[columnIndex] = detectWhiteCardFace(bitmap, occupancyRect)
            greenBackgroundConfirmed[columnIndex] =
                greenBackgroundRatio(bitmap, occupancyRect) >= .90f

            val crop = Bitmap.createBitmap(
                bitmap, colRect.left, colRect.top, colRect.width(), colRect.height()
            )
            val scale = 2
            val enlarged = Bitmap.createScaledBitmap(
                crop, crop.width * scale, crop.height * scale, true
            )
            try {
                val text = recognize(enlarged)
                if (text != null) {
                    for (block in text.textBlocks) for (line in block.lines) {
                        for (element in line.elements) {
                            val rank = parseRank(element.text) ?: continue
                            val box = element.boundingBox ?: continue
                            val mapped = Rect(
                                box.left / scale, box.top / scale,
                                box.right / scale, box.bottom / scale
                            )
                            val absolute = Rect(mapped).apply {
                                offset(colRect.left, colRect.top)
                            }
                            val cardTop = absolute.top.toFloat()
                            if (cardTop < TABLEAU_FIRST_Y * sy ||
                                cardTop > TABLEAU_LAST_Y * sy) continue

                            val inkRect = Rect(
                                (absolute.left - 4f * sx).toInt().coerceAtLeast(colRect.left),
                                (absolute.top - 4f * sy).toInt().coerceAtLeast(colRect.top),
                                (absolute.right + 38f * sx).toInt().coerceAtMost(colRect.right),
                                (absolute.bottom + 58f * sy).toInt().coerceAtMost(colRect.bottom)
                            )
                            val color = classifyColor(bitmap, inkRect)
                            val suit = classifySuit(bitmap, absolute, color, sx, sy)
                            val observation = CardObservation(
                                rank, color, suit, .86f, absolute, cardTop, centerPx
                            )
                            val existing = columns[columnIndex].firstOrNull {
                                abs(it.topY - cardTop) < 22f * sy
                            }
                            if (existing == null) {
                                columns[columnIndex].add(observation)
                                ocrCounts[columnIndex]++
                            }
                        }
                    }
                }
            } finally {
                enlarged.recycle()
                crop.recycle()
            }
        }

        val normalizedColumns = columns.mapIndexed { index, cards ->
            val sorted = cards.sortedBy { it.topY }
            // The initial deal gives column i+1 at least i+1 cards. This is only
            // a conservative lower-bound estimate; pixel checks can force >= 1.
            val estimatedHidden = max(0, index + 1 - sorted.size)
            val hidden = if (hiddenBackDetected[index]) max(1, estimatedHidden) else 0
            ColumnObservation(
                visibleCards = sorted,
                hiddenCount = hidden,
                hasCardFace = cardFaceDetected[index],
                hasHiddenCardBack = hiddenBackDetected[index],
                greenBackgroundConfirmed = greenBackgroundConfirmed[index]
            )
        }

        // Draw-3: read only the upper-left rank/suit corner of the free rightmost card.
        // Nothing left of reference X=525 enters this crop.
        val wasteRect = scaledRect(bitmap, 525f, 415f, 585f, 485f, sx, sy)
        val wasteCrop = Bitmap.createBitmap(
            bitmap, wasteRect.left, wasteRect.top, wasteRect.width(), wasteRect.height()
        )
        val binaryWaste = thresholdWasteCorner(wasteCrop)
        val wasteScale = 4
        val enlargedWaste = Bitmap.createScaledBitmap(
            binaryWaste, binaryWaste.width * wasteScale,
            binaryWaste.height * wasteScale, true
        )
        var waste: CardObservation? = null
        try {
            val wasteText = recognize(enlargedWaste)
            val rankElement = wasteText?.textBlocks
                ?.flatMap { it.lines }
                ?.flatMap { it.elements }
                ?.mapNotNull { element ->
                    val rank = parseRank(element.text) ?: return@mapNotNull null
                    val box = element.boundingBox ?: return@mapNotNull null
                    rank to box
                }
                ?.minByOrNull { (_, box) -> box.top * 10000 + box.left }

            if (rankElement != null) {
                val box = rankElement.second
                val local = Rect(
                    box.left / wasteScale, box.top / wasteScale,
                    box.right / wasteScale, box.bottom / wasteScale
                )
                val absolute = Rect(local).apply { offset(wasteRect.left, wasteRect.top) }
                val inkRect = Rect(
                    (absolute.left - 5f * sx).toInt().coerceAtLeast(0),
                    (absolute.top - 4f * sy).toInt().coerceAtLeast(0),
                    (absolute.right + 28f * sx).toInt().coerceAtMost(bitmap.width),
                    (absolute.bottom + 34f * sy).toInt().coerceAtMost(bitmap.height)
                )
                val color = classifyColor(bitmap, inkRect)
                val suit = classifySuit(bitmap, absolute, color, sx, sy)
                waste = CardObservation(
                    rankElement.first, color, suit, .95f, absolute,
                    absolute.top.toFloat(), WASTE_X * sx
                )
            }
        } finally {
            enlargedWaste.recycle()
            binaryWaste.recycle()
            wasteCrop.recycle()
        }

        // Closed stock pile at (610..700, 415..555).
        val stockRect = scaledRect(bitmap, 610f, 415f, 700f, 555f, sx, sy)
        val stockHasCard = detectRedBack(bitmap, stockRect)

        // Four foundation piles at the top-left.
        val foundationRanks = mutableMapOf<SolitaireEngine.Suit, Int>()
        val foundationSlots = mutableMapOf<SolitaireEngine.Suit, Int>()
        val occupiedFoundationSlots = mutableSetOf<Int>()
        for (suit in SolitaireEngine.Suit.values()) foundationRanks[suit] = 0

        for (i in foundationCenters.indices) {
            val fr = scaledRect(
                bitmap, foundationCenters[i] - 42f, TOP_ROW_Y - 5f,
                foundationCenters[i] + 42f, TOP_ROW_Y + 105f, sx, sy
            )
            val fc = Bitmap.createBitmap(bitmap, fr.left, fr.top, fr.width(), fr.height())
            try {
                val ft = recognize(fc)
                val topElement = ft?.textBlocks?.flatMap { it.lines }
                    ?.flatMap { it.elements }
                    ?.firstNotNullOfOrNull { element ->
                        parseRank(element.text)?.let { it to element }
                    }
                if (topElement != null && hasWhiteCardFace(fc)) {
                    val box = topElement.second.boundingBox ?: Rect(0, 0, fc.width, fc.height)
                    val color = classifyColor(fc, box)
                    val suit = classifySuit(fc, box, color, 1f, 1f)
                    if (suit != null) {
                        foundationRanks[suit] = topElement.first
                        foundationSlots[suit] = i
                        occupiedFoundationSlots += i
                    }
                }
            } finally {
                fc.recycle()
            }
        }

        val rankCount = normalizedColumns.sumOf { it.visibleCards.size } +
            if (waste != null) 1 else 0
        val detectedColumns = normalizedColumns.count { it.visibleCards.isNotEmpty() }
        val perColumn = ocrCounts.joinToString("/")
        val status = "OCR: $rankCount ورقة؛ أعمدة: $detectedColumns/7؛ قراءة الأعمدة: $perColumn"
        val suitDiagnostics = normalizedColumns.mapIndexed { i, col ->
            val state = when {
                col.visibleCards.isNotEmpty() -> cardLabel(col.visibleCards.last())
                col.hasHiddenCardBack -> "ظهر مخفي"
                col.hasCardFace -> "وجه غير مقروء"
                col.isCompletelyEmpty -> "فارغ أخضر مؤكّد"
                else -> "غير محسوم"
            }
            "C${i + 1}:[$state; مخفي=${col.hiddenCount}]"
        }.joinToString(" ")

        return BoardObservation(
            normalizedColumns, foundationRanks, foundationSlots,
            occupiedFoundationSlots, waste, stockHasCard,
            "الكومة:[${waste?.let { cardLabel(it) } ?: "لا يوجد"}]؛ $status؛ $suitDiagnostics"
        )
    }

    private fun recognize(bitmap: Bitmap): Text? {
        val latch = CountDownLatch(1)
        var result: Text? = null
        try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result = it }
                .addOnCompleteListener { latch.countDown() }
            if (!latch.await(1800, TimeUnit.MILLISECONDS)) return null
        } catch (_: Exception) {
            return null
        }
        return result
    }

    /** Converts the selected waste corner to black glyphs on a white background. */
    private fun thresholdWasteCorner(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        for (y in 0 until source.height) {
            for (x in 0 until source.width) {
                val pixel = source.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                val redInk = isCardBackRed(r, g, b)
                val darkInk = max(r, max(g, b)) < 145 &&
                    (max(r, max(g, b)) - minOf(r, g, b)) < 48
                val ink = redInk || darkInk
                output.setPixel(x, y, if (ink) Color.BLACK else Color.WHITE)
            }
        }
        return output
    }

    private fun scaledRect(
        bitmap: Bitmap, left: Float, top: Float, right: Float, bottom: Float,
        sx: Float, sy: Float
    ): Rect {
        val l = (left * sx).toInt().coerceIn(0, bitmap.width - 1)
        val t = (top * sy).toInt().coerceIn(0, bitmap.height - 1)
        val r = (right * sx).toInt().coerceIn(l + 1, bitmap.width)
        val b = (bottom * sy).toInt().coerceIn(t + 1, bitmap.height)
        return Rect(l, t, r, b)
    }

    private fun parseRank(raw: String): Int? {
        val text = raw.uppercase().replace(" ", "").replace("\n", "")
            .replace("|", "1").replace("O", "0")
        return when {
            text.contains("10") || text == "T" -> 10
            text.contains("K") -> 13
            text.contains("Q") -> 12
            text.contains("J") -> 11
            text.contains("A") -> 1
            else -> text.firstOrNull { it in '2'..'9' }?.digitToInt()
        }
    }

    private fun classifyColor(bitmap: Bitmap, rect: Rect): SolitaireEngine.SuitColor {
        var red = 0
        var black = 0
        val safeLeft = rect.left.coerceIn(0, bitmap.width - 1)
        val safeTop = rect.top.coerceIn(0, bitmap.height - 1)
        val safe = Rect(
            safeLeft,
            safeTop,
            rect.right.coerceIn(safeLeft + 1, bitmap.width),
            rect.bottom.coerceIn(safeTop + 1, bitmap.height)
        )
        val stepX = max(1, safe.width() / 24)
        val stepY = max(1, safe.height() / 24)
        for (y in safe.top until safe.bottom step stepY) {
            for (x in safe.left until safe.right step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                if (isCardBackRed(r, g, b)) red++
                if (r < 110 && g < 110 && b < 110) black++
            }
        }
        return if (red > 0 && red >= black) SolitaireEngine.SuitColor.RED
        else SolitaireEngine.SuitColor.BLACK
    }

    private fun hasWhiteCardFace(bitmap: Bitmap): Boolean {
        var brightNeutral = 0
        var sampled = 0
        val stepX = max(1, bitmap.width / 28)
        val stepY = max(1, bitmap.height / 28)
        for (y in 0 until bitmap.height step stepY) {
            for (x in 0 until bitmap.width step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                if (isCardWhite(r, g, b)) brightNeutral++
                sampled++
            }
        }
        return sampled > 0 && brightNeutral.toFloat() / sampled > .18f
    }

    /** Detects a white card face/edge in a tableau occupancy window. */
    private fun detectWhiteCardFace(bitmap: Bitmap, rect: Rect): Boolean {
        var white = 0
        var sampled = 0
        val stepX = max(1, rect.width() / 36)
        val stepY = max(1, rect.height() / 36)
        for (y in rect.top until rect.bottom step stepY) {
            for (x in rect.left until rect.right step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                if (isCardWhite(r, g, b)) white++
                sampled++
            }
        }
        return sampled > 0 && white.toFloat() / sampled >= .025f
    }

    private fun cardLabel(card: CardObservation): String {
        val rank = when (card.rank) {
            1 -> "A"
            11 -> "J"
            12 -> "Q"
            13 -> "K"
            else -> card.rank.toString()
        }
        val symbol = when (card.suit) {
            SolitaireEngine.Suit.HEARTS -> "♥"
            SolitaireEngine.Suit.DIAMONDS -> "♦"
            SolitaireEngine.Suit.SPADES -> "♠"
            SolitaireEngine.Suit.CLUBS -> "♣"
            null -> "?"
        }
        return rank + symbol
    }

    private fun classifySuit(
        bitmap: Bitmap, rankBox: Rect, color: SolitaireEngine.SuitColor,
        @Suppress("UNUSED_PARAMETER") sx: Float,
        @Suppress("UNUSED_PARAMETER") sy: Float
    ): SolitaireEngine.Suit? {
        val left = (rankBox.left + rankBox.width() * .48f)
            .toInt().coerceIn(0, bitmap.width - 1)
        val right = (rankBox.right + rankBox.width() * .75f)
            .toInt().coerceIn(left + 1, bitmap.width)
        val top = rankBox.top.coerceIn(0, bitmap.height - 1)
        val bottom = (rankBox.top + rankBox.height() * 1.05f)
            .toInt().coerceIn(top + 1, bitmap.height)
        val width = right - left
        val height = bottom - top
        if (width < 3 || height < 3) return null

        val rowWidths = IntArray(12)
        var count = 0
        for (gy in 0 until 12) for (gx in 0 until 12) {
            val x = (left + gx * width / 12).coerceAtMost(bitmap.width - 1)
            val y = (top + gy * height / 12).coerceAtMost(bitmap.height - 1)
            val pixel = bitmap.getPixel(x, y)
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)
            val ink = if (color == SolitaireEngine.SuitColor.RED)
                isCardBackRed(r, g, b)
            else r < 110 && g < 110 && b < 110
            if (ink) {
                rowWidths[gy]++
                count++
            }
        }
        if (count < 5) return null
        val upper = rowWidths.slice(0..3).sum()
        val middle = rowWidths.slice(4..7).sum()
        val lower = rowWidths.slice(8..11).sum()
        val widest = rowWidths.maxOrNull() ?: 0
        return if (color == SolitaireEngine.SuitColor.RED) {
            if (middle > upper * 1.12f && middle > lower * 1.12f)
                SolitaireEngine.Suit.DIAMONDS
            else SolitaireEngine.Suit.HEARTS
        } else {
            if (upper > lower * 1.18f || widest >= 8 && upper >= middle)
                SolitaireEngine.Suit.CLUBS
            else SolitaireEngine.Suit.SPADES
        }
    }

    /**
     * Color predicates tuned for compressed screenshots and darker Jawaker themes.
     * Ratios are deliberately channel-relative so brightness changes do not turn
     * maroon card backs into black or teal felt into green.
     */
    private fun isCardWhite(r: Int, g: Int, b: Int): Boolean {
        val minimum = minOf(r, g, b)
        val maximum = max(r, max(g, b))
        return minimum >= 178 && maximum - minimum <= 48
    }

    private fun isFeltGreen(r: Int, g: Int, b: Int): Boolean {
        return g >= 38 && g >= r * 1.08f && g >= b * 1.02f &&
            (g - minOf(r, b)) >= 10
    }

    private fun isCardBackRed(r: Int, g: Int, b: Int): Boolean {
        return r >= 62 && r >= g * 1.16f && r >= b * 1.13f &&
            (r - minOf(g, b)) >= 24
    }

    /** Returns the proportion of sampled pixels matching the green table felt. */
    private fun greenBackgroundRatio(bitmap: Bitmap, rect: Rect): Float {
        var green = 0
        var sampled = 0
        val stepX = max(1, rect.width() / 32)
        val stepY = max(1, rect.height() / 32)
        for (y in rect.top until rect.bottom step stepY) {
            for (x in rect.left until rect.right step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                if (isFeltGreen(r, g, b)) green++
                sampled++
            }
        }
        return if (sampled == 0) 0f else green.toFloat() / sampled
    }

    /** Red-backed card detector shared by hidden tableau cards and the stock pile. */
    private fun detectRedBack(bitmap: Bitmap, rect: Rect): Boolean {
        var redPixels = 0
        var sampled = 0
        var redSum = 0L
        for (y in rect.top until rect.bottom step max(1, rect.height() / 32)) {
            for (x in rect.left until rect.right step max(1, rect.width() / 32)) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                if (isCardBackRed(r, g, b)) redPixels++
                redSum += r.toLong()
                sampled++
            }
        }
        if (sampled == 0) return false
        val redRatio = redPixels.toFloat() / sampled
        val averageRed = redSum.toFloat() / sampled
        return redRatio >= .045f || (redRatio >= .025f && averageRed >= 95f)
    }
}
