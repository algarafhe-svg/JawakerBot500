package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Jawaker board reader calibrated to the user's 720x1640 screen coordinates. */
object CardVision {
    data class CardObservation(
        val rank: Int,
        val suitColor: SolitaireEngine.SuitColor,
        val confidence: Float,
        val bounds: Rect,
        val topY: Float,
        val centerX: Float
    )

    data class ColumnObservation(
        val visibleCards: List<CardObservation>, // top to bottom
        val hiddenCount: Int
    )

    data class BoardObservation(
        val columns: List<ColumnObservation>,
        val foundationRanks: List<Int?>,
        val waste: CardObservation?,
        val stockHasCard: Boolean,
        val diagnostics: String
    )

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // Coordinates are in the 720x1640 logical screenshot space and scaled to captured frames.
    private val columnCenters = floatArrayOf(65f, 165f, 265f, 365f, 465f, 565f, 665f)
    private val foundationCenters = floatArrayOf(75f, 190f, 305f, 420f)
    private const val TABLEAU_FIRST_Y = 470f
    private const val TABLEAU_LAST_Y = 950f
    private const val CARD_STEP_Y = 48f
    private const val STOCK_X = 655f
    private const val WASTE_X = 535f
    private const val TOP_ROW_Y = 365f

    fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also { padded.recycle() }
    }

    fun analyze(bitmap: Bitmap): BoardObservation {
        val sx = bitmap.width / 720f
        val sy = bitmap.height / 1640f
        val columns = MutableList(7) { mutableListOf<CardObservation>() }

        // One OCR pass for the whole tableau is substantially faster than OCR per card.
        val boardRect = Rect(
            0,
            (TABLEAU_FIRST_Y * sy - 35 * sy).toInt().coerceIn(0, bitmap.height - 1),
            bitmap.width,
            min(bitmap.height, (TABLEAU_LAST_Y * sy + 90 * sy).toInt())
        )
        val boardCrop = Bitmap.createBitmap(bitmap, boardRect.left, boardRect.top,
            boardRect.width(), boardRect.height())
        val boardText = recognize(boardCrop)
        boardCrop.recycle()

        if (boardText != null) {
            for (block in boardText.textBlocks) {
                for (line in block.lines) {
                    for (element in line.elements) {
                        val rank = parseRank(element.text) ?: continue
                        val box = element.boundingBox ?: continue
                        val absolute = Rect(box).apply { offset(boardRect.left, boardRect.top) }
                        val centerX = (absolute.centerX() + 34f * sx).coerceIn(0f, bitmap.width.toFloat())
                        val columnIndex = columnCenters.indices.minByOrNull {
                            abs(centerX - columnCenters[it] * sx)
                        } ?: continue
                        val expectedCenter = columnCenters[columnIndex] * sx
                        if (abs(centerX - expectedCenter) > 52f * sx) continue
                        val topY = absolute.top.toFloat()
                        if (topY < TABLEAU_FIRST_Y * sy - 20f * sy ||
                            topY > TABLEAU_LAST_Y * sy + 65f * sy) continue
                        val colorRect = Rect(
                            (expectedCenter - 43f * sx).toInt().coerceAtLeast(0),
                            topY.toInt().coerceAtLeast(0),
                            (expectedCenter + 8f * sx).toInt().coerceAtMost(bitmap.width),
                            (topY + 62f * sy).toInt().coerceAtMost(bitmap.height)
                        )
                        if (colorRect.width() < 2 || colorRect.height() < 2) continue
                        val color = classifyColor(bitmap, colorRect)
                        val observation = CardObservation(rank, color, .78f, absolute,
                            topY, expectedCenter)
                        val existing = columns[columnIndex].firstOrNull { abs(it.topY - topY) < 18f * sy }
                        if (existing == null) columns[columnIndex].add(observation)
                        else if (observation.confidence > existing.confidence) {
                            columns[columnIndex].remove(existing)
                            columns[columnIndex].add(observation)
                        }
                    }
                }
            }
        }

        val normalizedColumns = columns.mapIndexed { index, cards ->
            val sorted = cards.sortedBy { it.topY }
            // Card-back count is only an estimate; the planner uses visible face-up sequences.
            val expectedStart = TABLEAU_FIRST_Y * sy
            val hiddenEstimate = max(0, index - (sorted.size - 1)).coerceAtMost(6)
            ColumnObservation(sorted, hiddenEstimate)
        }

        val wasteRect = scaledRect(bitmap, WASTE_X - 48f, TOP_ROW_Y - 38f, WASTE_X + 45f, TOP_ROW_Y + 85f, sx, sy)
        val wasteCrop = Bitmap.createBitmap(bitmap, wasteRect.left, wasteRect.top,
            wasteRect.width(), wasteRect.height())
        val wasteText = recognize(wasteCrop)
        var waste: CardObservation? = null
        if (wasteText != null) {
            val element = wasteText.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                .firstNotNullOfOrNull { el -> parseRank(el.text)?.let { it to el } }
            if (element != null) {
                val b = element.second.boundingBox ?: Rect(0, 0, wasteCrop.width, wasteCrop.height)
                val inkRect = Rect(
                    (b.left - 6).coerceAtLeast(0), (b.top - 4).coerceAtLeast(0),
                    (b.right + 30).coerceAtMost(wasteCrop.width),
                    (b.bottom + 55).coerceAtMost(wasteCrop.height)
                )
                val color = classifyColor(wasteCrop, inkRect)
                val absBox = Rect(b).apply { offset(wasteRect.left, wasteRect.top) }
                waste = CardObservation(element.first, color, .75f, absBox,
                    absBox.top.toFloat(), WASTE_X * sx)
            }
        }
        wasteCrop.recycle()

        val stockRect = scaledRect(bitmap, STOCK_X - 42f, TOP_ROW_Y - 40f,
            STOCK_X + 42f, TOP_ROW_Y + 90f, sx, sy)
        val stockHasCard = detectRedBack(bitmap, stockRect)

        val rankCount = normalizedColumns.sumOf { it.visibleCards.size } + if (waste != null) 1 else 0
        val status = "OCR: $rankCount ورقة؛ أعمدة: ${normalizedColumns.count { it.visibleCards.isNotEmpty() }}/7؛ إطار ${bitmap.width}x${bitmap.height}"
        return BoardObservation(normalizedColumns, listOf(null, null, null, null), waste,
            stockHasCard, status)
    }

    private fun recognize(bitmap: Bitmap): Text? {
        val latch = CountDownLatch(1)
        var result: Text? = null
        try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result = it }
                .addOnCompleteListener { latch.countDown() }
            latch.await(1800, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        }
        return result
    }

    private fun scaledRect(bitmap: Bitmap, left: Float, top: Float, right: Float, bottom: Float,
                           sx: Float, sy: Float): Rect {
        val l = (left * sx).toInt().coerceIn(0, bitmap.width - 1)
        val t = (top * sy).toInt().coerceIn(0, bitmap.height - 1)
        val r = (right * sx).toInt().coerceIn(l + 1, bitmap.width)
        val b = (bottom * sy).toInt().coerceIn(t + 1, bitmap.height)
        return Rect(l, t, r, b)
    }

    private fun parseRank(raw: String): Int? {
        val text = raw.uppercase().replace(" ", "").replace("\n", "")
            .replace("|", "1").replace("O", "0")
        return when {
            text.contains("10") || text == "T" -> 10
            text.contains("K") -> 13
            text.contains("Q") -> 12
            text.contains("J") -> 11
            text.contains("A") -> 1
            else -> text.firstOrNull { it in '2'..'9' }?.digitToInt()
        }
    }

    private fun classifyColor(bitmap: Bitmap, rect: Rect): SolitaireEngine.SuitColor {
        var red = 0
        var dark = 0
        val stepX = max(1, rect.width() / 24)
        val stepY = max(1, rect.height() / 24)
        for (y in rect.top until rect.bottom step stepY) {
            for (x in rect.left until rect.right step stepX) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 105 && r > g * 1.25f && r > b * 1.20f) red++
                if (r < 105 && g < 105 && b < 105) dark++
            }
        }
        return if (red >= dark) SolitaireEngine.SuitColor.RED else SolitaireEngine.SuitColor.BLACK
    }

    private fun detectRedBack(bitmap: Bitmap, rect: Rect): Boolean {
        var red = 0
        var sampled = 0
        for (y in rect.top until rect.bottom step max(1, rect.height() / 24)) {
            for (x in rect.left until rect.right step max(1, rect.width() / 24)) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 85 && r > g * 1.25f && r > b * 1.2f) red++
                sampled++
            }
        }
        return sampled > 0 && red.toFloat() / sampled > .075f
    }
}
