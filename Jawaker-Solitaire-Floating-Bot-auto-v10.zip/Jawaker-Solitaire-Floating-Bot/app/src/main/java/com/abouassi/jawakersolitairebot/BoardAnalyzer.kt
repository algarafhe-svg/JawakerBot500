package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.media.Image
import kotlin.math.abs
import java.util.ArrayDeque

/** Reads the current board and returns one legal tableau/waste move or a stock tap. */
object BoardAnalyzer {
    data class Move(
        val fromX: Float,
        val fromY: Float,
        val toX: Float,
        val toY: Float,
        val durationMs: Long = 430L,
        val isTap: Boolean = false
    )

    data class Analysis(val status: String, val proposedMove: Move? = null)

    private const val REF_W = 720f
    private const val REF_H = 1640f
    private const val FIRST_CARD_Y = 585f
    private const val WASTE_X = 540f
    private const val WASTE_Y = 485f
    private const val DEFAULT_DRAG_MS = 400L
    private const val MOVE_HISTORY_LIMIT = 60
    private val recentMoveKeys = ArrayDeque<String>()
    private val recentMoveSet = mutableSetOf<String>()
    private var stockDrawCount = 0
    private const val MAX_STOCK_DRAWS_WITHOUT_MOVE = 24

    fun analyze(image: Image, width: Int, height: Int): Analysis {
        val bitmap = try { CardVision.imageToBitmap(image) }
        catch (_: Exception) { return Analysis("تعذر تحويل لقطة الشاشة") }
        return try { analyze(bitmap) } finally { bitmap.recycle() }
    }

    fun analyze(bitmap: Bitmap): Analysis {
        val board = try { CardVision.analyze(bitmap) }
        catch (e: Exception) {
            return Analysis("خطأ قراءة اللوحة: ${e.message ?: "غير معروف"}")
        }
        val sx = bitmap.width / REF_W
        val sy = bitmap.height / REF_H
        val cols = board.columns
        if (cols.size != 7) return Analysis("لم أتعرف على الأعمدة السبعة. ${board.diagnostics}")
        val detectedTableauCards = cols.sumOf { it.visibleCards.size }
        if (detectedTableauCards < 4) {
            return Analysis("قراءة الكروت غير كافية ($detectedTableauCards فقط)؛ لن أنقر عشوائياً. ${board.diagnostics}")
        }

        data class Candidate(val move: Move, val score: Int, val label: String)
        val foundationCandidates = mutableListOf<Candidate>()
        val tableauCandidates = mutableListOf<Candidate>()
        val wasteCandidates = mutableListOf<Candidate>()

        // Priority 1: exposed tableau cards to foundation, only when exact suit is known.
        for (from in cols.indices) {
            val card = cols[from].visibleCards.lastOrNull() ?: continue
            val suit = card.suit ?: continue
            val current = board.foundationRanks[suit] ?: 0
            if ((current == 0 && card.rank == 1) || card.rank == current + 1) {
                foundationCandidates += Candidate(
                    Move(card.centerX * sx, card.topY + 24f * sy,
                        foundationTargetX(board, suit) * sx, 365f * sy, DEFAULT_DRAG_MS),
                    500, "رفع ${rankName(card.rank)}${suitSymbol(suit)} من العمود ${from + 1} إلى الأساس")
            }
        }
        board.waste?.let { card ->
            val suit = card.suit
            if (suit != null) {
                val current = board.foundationRanks[suit] ?: 0
                if ((current == 0 && card.rank == 1) || card.rank == current + 1) {
                    foundationCandidates += Candidate(
                        Move(WASTE_X * sx, WASTE_Y * sy, foundationTargetX(board, suit) * sx,
                            365f * sy, DEFAULT_DRAG_MS), 490, "رفع ${rankName(card.rank)}${suitSymbol(suit)} من المخلفات إلى الأساس")
                }
            }
        }
        val bestFoundation = foundationCandidates.firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestFoundation != null) {
            rememberMove(bestFoundation.move)
            stockDrawCount = 0
            return Analysis("${board.diagnostics} — حركة أولوية 1: ${bestFoundation.label}", bestFoundation.move)
        }

        // Priority 2: move a valid descending alternating-colour suffix between tableau columns.
        for (from in cols.indices) {
            val source = cols[from].visibleCards
            if (source.isEmpty()) continue
            for (start in source.indices) {
                val suffix = source.drop(start)
                if (!isValidSequence(suffix)) continue
                val moving = suffix.first()
                for (to in cols.indices) {
                    if (to == from) continue
                    val targetCards = cols[to].visibleCards
                    val target = targetCards.lastOrNull()
                    val targetIsCompletelyEmpty = targetCards.isEmpty() && cols[to].hiddenCount == 0
                    val legal = if (targetIsCompletelyEmpty) moving.rank == 13
                        else target != null && moving.suitColor != target.suitColor && moving.rank == target.rank - 1
                    if (!legal) continue
                    // Use the OCR card's own horizontal centre and its exposed
                    // rank-strip position, rather than a guessed fixed column point.
                    val sourceX = moving.centerX * sx
                    val targetX = CardVisionCenter.column(to) * sx
                    // Start at the exposed header of the first card in the valid suffix. This
                    // makes the entire ordered run move together, not the lower tail card.
                    val sourceY = (moving.topY + 24f * sy).coerceIn(0f, bitmap.height.toFloat())
                    val targetTop = target?.topY ?: FIRST_CARD_Y * sy
                    val targetY = (targetTop + 38f * sy).coerceAtMost(bitmap.height.toFloat())
                    val revealBonus = if (start == 0 && cols[from].hiddenCount > 0) 35 else 0
                    // Tableau-to-tableau moves have strict priority over waste moves.
                    val score = 300 + revealBonus + if (targetIsCompletelyEmpty) 5 else 0
                    tableauCandidates += Candidate(Move(sourceX, sourceY, targetX, targetY, DEFAULT_DRAG_MS), score,
                        "${rankName(moving.rank)} من العمود ${from + 1} إلى ${to + 1}")
                }
            }
        }

        // The waste card can be placed on a legal tableau column.
        board.waste?.let { waste ->
            for (to in cols.indices) {
                val target = cols[to].visibleCards.lastOrNull()
                val targetIsCompletelyEmpty = board.columns[to].visibleCards.isEmpty() &&
                    board.columns[to].hiddenCount == 0
                val legal = if (targetIsCompletelyEmpty) waste.rank == 13
                    else target != null && waste.suitColor != target.suitColor && waste.rank == target.rank - 1
                if (legal) {
                    val targetY = (target?.topY ?: FIRST_CARD_Y * sy) + 38f * sy
                    wasteCandidates += Candidate(
                        Move(WASTE_X * sx, WASTE_Y * sy, CardVisionCenter.column(to) * sx, targetY, DEFAULT_DRAG_MS),
                        200, "نقل ${rankName(waste.rank)} من المخلفات إلى العمود ${to + 1}"
                    )
                }
            }
        }

        // Strict priority 2 before priority 3; avoid loops within each tier.
        val bestTableau = tableauCandidates.sortedByDescending { it.score }
            .firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestTableau != null) {
            rememberMove(bestTableau.move)
            stockDrawCount = 0
            return Analysis("${board.diagnostics} — حركة أولوية 2: ${bestTableau.label}", bestTableau.move)
        }
        val bestWaste = wasteCandidates.sortedByDescending { it.score }
            .firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestWaste != null) {
            rememberMove(bestWaste.move)
            stockDrawCount = 0
            return Analysis("${board.diagnostics} — حركة أولوية 3: ${bestWaste.label}", bestWaste.move)
        }

        // Priority 4: draw only after all foundation/tableau/waste moves are exhausted.
        if (board.stockHasCard && stockDrawCount < MAX_STOCK_DRAWS_WITHOUT_MOVE) {
            val stockX = 655f * sx
            val stockY = 485f * sy
            stockDrawCount++
            return Analysis("${board.diagnostics} — لا توجد حركة؛ سحب ${stockDrawCount}/${MAX_STOCK_DRAWS_WITHOUT_MOVE}",
                Move(stockX, stockY, stockX, stockY, 80L, true))
        }
        return Analysis("${board.diagnostics} — توقف السحب بعد دورة كاملة دون حركة؛ راجع قراءة الأوراق")
    }


    @Synchronized
    private fun moveKey(move: Move): String = listOf(
        move.fromX.toInt(), move.fromY.toInt(), move.toX.toInt(), move.toY.toInt(), move.isTap
    ).joinToString(":")

    @Synchronized
    private fun isRecentlyRepeated(move: Move): Boolean {
        val key = moveKey(move)
        if (key in recentMoveSet) return true
        val reverse = listOf(move.toX.toInt(), move.toY.toInt(), move.fromX.toInt(),
            move.fromY.toInt(), move.isTap).joinToString(":")
        return !move.isTap && reverse in recentMoveSet
    }

    @Synchronized
    private fun rememberMove(move: Move) {
        val key = moveKey(move)
        recentMoveKeys.addLast(key)
        recentMoveSet.add(key)
        while (recentMoveKeys.size > MOVE_HISTORY_LIMIT) {
            val old = recentMoveKeys.removeFirst()
            if (old !in recentMoveKeys) recentMoveSet.remove(old)
        }
    }

    private fun isValidSequence(cards: List<CardVision.CardObservation>): Boolean {
        if (cards.isEmpty()) return false
        for (i in 0 until cards.lastIndex) {
            val upper = cards[i]
            val lower = cards[i + 1]
            val verticalGap = abs(lower.topY - upper.topY)
            if (verticalGap > 105f || verticalGap < 18f ||
                upper.suitColor == lower.suitColor || upper.rank != lower.rank + 1) return false
        }
        return true
    }

    private fun rankName(rank: Int): String = when (rank) {
        1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> rank.toString()
    }

    private fun foundationTargetX(board: CardVision.BoardObservation, suit: SolitaireEngine.Suit): Float {
        val existing = board.foundationSlots[suit]
        if (existing != null) return CardVisionCenter.foundationSlot(existing)
        // An Ace starts a new pile in the first visually unoccupied foundation slot.
        val free = (0..3).firstOrNull { it !in board.occupiedFoundationSlots } ?: 0
        return CardVisionCenter.foundationSlot(free)
    }

    private fun suitSymbol(suit: SolitaireEngine.Suit): String = when (suit) {
        SolitaireEngine.Suit.HEARTS -> "♥"
        SolitaireEngine.Suit.DIAMONDS -> "♦"
        SolitaireEngine.Suit.SPADES -> "♠"
        SolitaireEngine.Suit.CLUBS -> "♣"
    }

    private object CardVisionCenter {
        private val centers = floatArrayOf(60f, 160f, 260f, 360f, 460f, 560f, 660f)
        fun column(index: Int): Float = centers[index]
        private val foundationCenters = floatArrayOf(75f, 190f, 305f, 420f)
        fun foundationSlot(index: Int): Float = foundationCenters[index.coerceIn(0, 3)]
    }
}
