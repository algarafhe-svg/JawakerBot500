package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Jawaker board reader calibrated to the user's 720x1640 screen coordinates. */
object CardVision {
    data class CardObservation(
        val rank: Int,
        val suitColor: SolitaireEngine.SuitColor,
        val suit: SolitaireEngine.Suit?,
        val confidence: Float,
        val bounds: Rect,
        val topY: Float,
        val centerX: Float
    )

    data class ColumnObservation(
        val visibleCards: List<CardObservation>, // top to bottom
        val hiddenCount: Int
    )

    data class BoardObservation(
        val columns: List<ColumnObservation>,
        val foundationRanks: Map<SolitaireEngine.Suit, Int>,
        val foundationSlots: Map<SolitaireEngine.Suit, Int>,
        val occupiedFoundationSlots: Set<Int>,
        val waste: CardObservation?,
        val stockHasCard: Boolean,
        val diagnostics: String
    )

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // Coordinates are in the 720x1640 logical screenshot space and scaled to captured frames.
    private val columnCenters = floatArrayOf(60f, 160f, 260f, 360f, 460f, 560f, 660f)
    private val foundationCenters = floatArrayOf(75f, 190f, 305f, 420f)
    private const val TABLEAU_FIRST_Y = 585f
    private const val TABLEAU_LAST_Y = 1200f
    private const val CARD_STEP_Y = 48f
    private const val STOCK_X = 655f
    private const val STOCK_Y = 485f
    private const val WASTE_X = 535f
    private const val TOP_ROW_Y = 365f

    fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also { padded.recycle() }
    }

    fun analyze(bitmap: Bitmap): BoardObservation {
        val sx = bitmap.width / 720f
        val sy = bitmap.height / 1640f
        val columns = MutableList(7) { mutableListOf<CardObservation>() }
        val ocrCounts = IntArray(7)

        // Read each of the seven columns independently and upscale its crop before
        // OCR. The original crops were only about 90 px wide on this device; ML Kit
        // frequently skipped the small rank glyphs in columns 1, 3, 5 and 7.
        for (columnIndex in columnCenters.indices) {
            val center = columnCenters[columnIndex] * sx
            // Full-height scan: include the rank strip near the top and the lowest
            // exposed card even when a long column extends well below the old crop.
            // Every crop is bounded to its own 100px lane so neighbouring columns
            // cannot donate OCR text to this column.
            val colLeft = if (columnIndex == 0) 10f else columnCenters[columnIndex] - 50f
            val colRight = if (columnIndex == 6) 710f else columnCenters[columnIndex] + 50f
            val colRect = scaledRect(
                bitmap, colLeft, 470f, colRight, 1200f, sx, sy
            )
            val crop = Bitmap.createBitmap(bitmap, colRect.left, colRect.top,
                colRect.width(), colRect.height())
            val scale = 2
            val enlarged = Bitmap.createScaledBitmap(crop, crop.width * scale,
                crop.height * scale, true)
            val text = recognize(enlarged)
            if (text != null) {
                for (block in text.textBlocks) for (line in block.lines) {
                    for (element in line.elements) {
                        val rank = parseRank(element.text) ?: continue
                        val box = element.boundingBox ?: continue
                        // OCR coordinates belong to the enlarged crop; map them back
                        // to the captured frame before sampling pixels or dispatching taps.
                        val mapped = Rect(box.left / scale, box.top / scale,
                            box.right / scale, box.bottom / scale)
                        val absolute = Rect(mapped).apply { offset(colRect.left, colRect.top) }
                        val cardTop = absolute.top.toFloat()
                        if (cardTop < TABLEAU_FIRST_Y * sy - 38f * sy ||
                            cardTop > TABLEAU_LAST_Y * sy + 90f * sy) continue
                        val inkRect = Rect(
                            (absolute.left - 4f * sx).toInt().coerceAtLeast(colRect.left),
                            (absolute.top - 4f * sy).toInt().coerceAtLeast(colRect.top),
                            (absolute.right + 38f * sx).toInt().coerceAtMost(colRect.right),
                            (absolute.bottom + 58f * sy).toInt().coerceAtMost(colRect.bottom)
                        )
                        val color = classifyColor(bitmap, inkRect)
                        val suit = classifySuit(bitmap, absolute, color, sx, sy)
                        val observation = CardObservation(rank, color, suit, .86f, absolute,
                            cardTop, center)
                        val existing = columns[columnIndex].firstOrNull {
                            abs(it.topY - cardTop) < 22f * sy
                        }
                        if (existing == null) {
                            columns[columnIndex].add(observation)
                            ocrCounts[columnIndex]++
                        }
                    }
                }
            }
            enlarged.recycle()
            crop.recycle()
        }

        val normalizedColumns = columns.mapIndexed { index, cards ->
            val sorted = cards.sortedBy { it.topY }
            // Card-back count is only an estimate; the planner uses visible face-up sequences.
            val expectedStart = TABLEAU_FIRST_Y * sy
            val hiddenEstimate = max(0, index - (sorted.size - 1)).coerceAtMost(6)
            ColumnObservation(sorted, hiddenEstimate)
        }

        val wasteRect = scaledRect(bitmap, WASTE_X - 48f, TOP_ROW_Y - 38f, WASTE_X + 45f, TOP_ROW_Y + 85f, sx, sy)
        val wasteCrop = Bitmap.createBitmap(bitmap, wasteRect.left, wasteRect.top,
            wasteRect.width(), wasteRect.height())
        val wasteText = recognize(wasteCrop)
        var waste: CardObservation? = null
        if (wasteText != null) {
            val element = wasteText.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                .firstNotNullOfOrNull { el -> parseRank(el.text)?.let { it to el } }
            if (element != null) {
                val b = element.second.boundingBox ?: Rect(0, 0, wasteCrop.width, wasteCrop.height)
                val inkRect = Rect(
                    (b.left - 6).coerceAtLeast(0), (b.top - 4).coerceAtLeast(0),
                    (b.right + 30).coerceAtMost(wasteCrop.width),
                    (b.bottom + 55).coerceAtMost(wasteCrop.height)
                )
                val color = classifyColor(wasteCrop, inkRect)
                val suit = classifySuit(wasteCrop, b, color, 1f, 1f)
                val absBox = Rect(b).apply { offset(wasteRect.left, wasteRect.top) }
                waste = CardObservation(element.first, color, suit, .75f, absBox,
                    absBox.top.toFloat(), WASTE_X * sx)
            }
        }
        wasteCrop.recycle()

        // Stock is at the user's observed red pile bounds (610..700, 415..555).
        val stockRect = scaledRect(bitmap, 610f, 415f, 700f, 555f, sx, sy)
        val stockHasCard = detectRedBack(bitmap, stockRect)

        // Read the four foundation piles independently. Empty placeholders have no card rank.
        val foundationRanks = mutableMapOf<SolitaireEngine.Suit, Int>()
        val foundationSlots = mutableMapOf<SolitaireEngine.Suit, Int>()
        val occupiedFoundationSlots = mutableSetOf<Int>()
        for (suit in SolitaireEngine.Suit.values()) foundationRanks[suit] = 0
        for (i in foundationCenters.indices) {
            val fr = scaledRect(bitmap, foundationCenters[i] - 42f, TOP_ROW_Y - 5f,
                foundationCenters[i] + 42f, TOP_ROW_Y + 105f, sx, sy)
            val fc = Bitmap.createBitmap(bitmap, fr.left, fr.top, fr.width(), fr.height())
            val ft = recognize(fc)
            val topElement = ft?.textBlocks?.flatMap { it.lines }?.flatMap { it.elements }
                ?.firstNotNullOfOrNull { el -> parseRank(el.text)?.let { it to el } }
            if (topElement != null && hasWhiteCardFace(fc)) {
                val b = topElement.second.boundingBox ?: Rect(0, 0, fc.width, fc.height)
                val c = classifyColor(fc, b)
                val suit = classifySuit(fc, b, c, 1f, 1f)
                if (suit != null) {
                    foundationRanks[suit] = topElement.first
                    foundationSlots[suit] = i
                    occupiedFoundationSlots += i
                }
            }
            fc.recycle()
        }

        val rankCount = normalizedColumns.sumOf { it.visibleCards.size } + if (waste != null) 1 else 0
        val detectedColumns = normalizedColumns.count { it.visibleCards.isNotEmpty() }
        val perColumn = ocrCounts.joinToString("/")
        val status = "OCR: $rankCount ورقة؛ أعمدة: $detectedColumns/7؛ قراءة الأعمدة: $perColumn؛ إطار ${bitmap.width}x${bitmap.height}"
        // Live debug reports the bottom-most exposed card in each column, the
        // actual free card that can be moved or used as a tableau target.
        val suitDiagnostics = normalizedColumns.mapIndexed { i, col ->
            "C${i + 1}:[${col.visibleCards.lastOrNull()?.let { cardLabel(it) } ?: "?"}]"
        }.joinToString(" ")
        return BoardObservation(normalizedColumns, foundationRanks, foundationSlots,
            occupiedFoundationSlots, waste, stockHasCard,
            "$status؛ $suitDiagnostics؛ Stock=$stockHasCard")
    }

    private fun recognize(bitmap: Bitmap): Text? {
        val latch = CountDownLatch(1)
        var result: Text? = null
        try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result = it }
                .addOnCompleteListener { latch.countDown() }
            latch.await(1800, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        }
        return result
    }

    private fun scaledRect(bitmap: Bitmap, left: Float, top: Float, right: Float, bottom: Float,
                           sx: Float, sy: Float): Rect {
        val l = (left * sx).toInt().coerceIn(0, bitmap.width - 1)
        val t = (top * sy).toInt().coerceIn(0, bitmap.height - 1)
        val r = (right * sx).toInt().coerceIn((l + 1).coerceAtMost(bitmap.width), bitmap.width)
        val b = (bottom * sy).toInt().coerceIn((t + 1).coerceAtMost(bitmap.height), bitmap.height)
        return Rect(l, t, r, b)
    }

    private fun parseRank(raw: String): Int? {
        val text = raw.uppercase().replace(" ", "").replace("\n", "")
            .replace("|", "1").replace("O", "0")
        return when {
            text.contains("10") || text == "T" -> 10
            text.contains("K") -> 13
            text.contains("Q") -> 12
            text.contains("J") -> 11
            text.contains("A") -> 1
            else -> text.firstOrNull { it in '2'..'9' }?.digitToInt()
        }
    }

    private fun classifyColor(bitmap: Bitmap, rect: Rect): SolitaireEngine.SuitColor {
        var red = 0
        var dark = 0
        val stepX = max(1, rect.width() / 24)
        val stepY = max(1, rect.height() / 24)
        for (y in rect.top until rect.bottom step stepY) {
            for (x in rect.left until rect.right step stepX) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 105 && r > g * 1.25f && r > b * 1.20f) red++
                if (r < 105 && g < 105 && b < 105) dark++
            }
        }
        return if (red >= dark) SolitaireEngine.SuitColor.RED else SolitaireEngine.SuitColor.BLACK
    }

    private fun hasWhiteCardFace(bitmap: Bitmap): Boolean {
        var brightNeutral = 0
        var sampled = 0
        val stepX = max(1, bitmap.width / 28)
        val stepY = max(1, bitmap.height / 28)
        for (y in 0 until bitmap.height step stepY) for (x in 0 until bitmap.width step stepX) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 185 && g > 185 && b > 185 && kotlin.math.abs(r - g) < 35 && kotlin.math.abs(g - b) < 35) brightNeutral++
            sampled++
        }
        return sampled > 0 && brightNeutral.toFloat() / sampled > .18f
    }

    private fun cardLabel(card: CardObservation): String {
        val rank = when (card.rank) { 1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> card.rank.toString() }
        val symbol = when (card.suit) {
            SolitaireEngine.Suit.HEARTS -> "♥"
            SolitaireEngine.Suit.DIAMONDS -> "♦"
            SolitaireEngine.Suit.SPADES -> "♠"
            SolitaireEngine.Suit.CLUBS -> "♣"
            null -> "?"
        }
        return rank + symbol
    }

    /** Classifies the small suit glyph beside the rank using its binary silhouette. */
    private fun classifySuit(bitmap: Bitmap, rankBox: Rect, color: SolitaireEngine.SuitColor,
                             sx: Float, sy: Float): SolitaireEngine.Suit? {
        val left = (rankBox.left + rankBox.width() * .48f).toInt().coerceIn(0, bitmap.width - 1)
        val right = (rankBox.right + rankBox.width() * .75f).toInt().coerceIn(left + 1, bitmap.width)
        val top = rankBox.top.coerceIn(0, bitmap.height - 1)
        val bottom = (rankBox.top + rankBox.height() * 1.05f).toInt().coerceIn(top + 1, bitmap.height)
        val w = right - left; val h = bottom - top
        if (w < 3 || h < 3) return null
        val rowWidths = IntArray(12)
        val colHeights = IntArray(12)
        var count = 0
        for (gy in 0 until 12) for (gx in 0 until 12) {
            val x = left + gx * w / 12
            val y = top + gy * h / 12
            val px = bitmap.getPixel(x, y)
            val r = Color.red(px); val g = Color.green(px); val b = Color.blue(px)
            val ink = if (color == SolitaireEngine.SuitColor.RED)
                r > 115 && r > g * 1.22f && r > b * 1.18f
            else r < 105 && g < 105 && b < 105
            if (ink) { rowWidths[gy]++; colHeights[gx]++; count++ }
        }
        if (count < 5) return null
        val upper = rowWidths.slice(0..3).sum()
        val middle = rowWidths.slice(4..7).sum()
        val lower = rowWidths.slice(8..11).sum()
        val widest = rowWidths.maxOrNull() ?: 0
        return if (color == SolitaireEngine.SuitColor.RED) {
            // Diamond narrows at both ends and is widest in its middle; heart has broad lobes above.
            if (middle > upper * 1.12f && middle > lower * 1.12f) SolitaireEngine.Suit.DIAMONDS
            else SolitaireEngine.Suit.HEARTS
        } else {
            // Club has a broad multi-lobed crown; spade has a pointed crown and broader lower body.
            if (upper > lower * 1.18f || widest >= 8 && upper >= middle) SolitaireEngine.Suit.CLUBS
            else SolitaireEngine.Suit.SPADES
        }
    }

    private fun detectRedBack(bitmap: Bitmap, rect: Rect): Boolean {
        var red = 0
        var sampled = 0
        var redSum = 0L
        for (y in rect.top until rect.bottom step max(1, rect.height() / 24)) {
            for (x in rect.left until rect.right step max(1, rect.width() / 24)) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 140) red++
                redSum += r.toLong()
                sampled++
            }
        }
        val averageRed = if (sampled == 0) 0f else redSum.toFloat() / sampled
        return sampled > 0 && (averageRed > 140f || red.toFloat() / sampled > .035f)
    }
}
