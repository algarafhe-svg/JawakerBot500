# Jawaker Solitaire Floating Bot

مشروع Android/Kotlin تجريبي لـ Android 10+، مع نافذة عائمة والتقاط شاشة وقراءة OCR ومحاولة تنفيذ نقلات Solitaire.

## الإحداثيات المعتمدة (720x1640)
- مخزون السحب: (655,365)
- الكرت المكشوف: (535,365)
- خانات الأساس: X=75,190,305,420 عند Y=365
- مراكز الأعمدة: X=65,165,265,365,465,565,665
- منطقة الأعمدة: Y=470 إلى Y=950

## ما ينفذه هذا الإصدار
- OCR واحد لمنطقة الأعمدة لاستخراج الرتب الظاهرة.
- تصنيف حبر الكرت إلى أحمر أو أسود.
- تخطيط نقلات الأعمدة وفق التناوب أحمر/أسود والترتيب التنازلي.
- نقل الكرت المكشوف من المخزون إلى عمود عند توفر حركة قانونية.
- سحب من المخزون عبر نقرة Accessibility إذا لم يجد حركة وكان ظهر المخزون ظاهرًا.
- عرض حالة التحليل والتنفيذ في النافذة العائمة.

## حدود مهمة
هذا إصدار تجريبي ويحتاج اختبارًا مباشرًا على الجهاز. دقة OCR وتصنيف اللون تتأثر بحركة الكروت والرسوم والطبقات العائمة. إذا لم يتعرف على عدد كافٍ من الكروت، يتوقف بدل النقر العشوائي. لا ينفذ نقلات الأساس حاليًا؛ لأن اللون الأحمر/الأسود والرتبة وحدهما لا يميزان نوع الورقة (♥ ♦ ♣ ♠) ولا يحددان خانة الأساس الصحيحة. لذلك لا تعتبره لاعبًا آليًا كاملًا أو مضمون الفوز.

## إعداد الهاتف
1. اسمح للنافذة العائمة.
2. فعّل `Jawaker Bot Gesture Service` من إعدادات إمكانية الوصول.
3. ابدأ التقاط الشاشة ووافق على طلب Android.
4. افتح لعبة Solitaire ثم اضغط تشغيل في النافذة العائمة.

## البناء
ارفع ملف `Jawaker-Solitaire-Floating-Bot-auto-v3.zip` إلى جذر مستودع GitHub، واستبدل `.github/workflows/build.yml` بالنسخة الموجودة في المشروع، ثم شغّل workflow باسم `Android Debug APK`. بعد نجاحه، نزّل `Jawaker-Bot-APK` من Artifacts.

## 720x1640 calibration update
- Tableau OCR now runs on seven independent column crops centered at X=65,165,265,365,465,565,665, rather than one wide crop. This avoids ML Kit merging rank labels across adjacent columns and improves the 7/7 column count.
- Stock detection samples a wider stock-card region around X=655, Y=365 and uses a more tolerant red-back threshold.
- The floating panel now starts near the bottom of the display (approximately 270dp above the bottom edge), leaving the top stock and foundation row visible. It remains draggable by its header.

The calibration is based on the supplied 720x1640 game layout. OCR and stock detection still need a live-device run to verify behavior under the game's animations and overlay composition.

## Solitaire rules update (V6)
- Empty foundations accept Ace only; later foundation cards must be the next rank of the same suit.
- Kings may be moved only to a tableau column with zero face-up and zero face-down cards.
- Move planning is tiered: tableau foundation, tableau-to-tableau, waste, then stock.
- Recent identical and immediate reverse tableau moves are suppressed to reduce loops.
- The screen OCR currently identifies rank and red/black color, but not the exact suit symbol for every card/foundation. Therefore the visual analyzer does not guess same-suit foundation moves; the rule engine supports exact-suit foundation decisions when suit data is available.


## V9 changes
- Full-height OCR scan for all seven tableau lanes (Y=470..1200), with bottom-most exposed-card labels in live diagnostics.
- Tableau and waste drags use 350 ms gestures; source positions use each OCR card observation.
- Stock taps are limited to 24 without an intervening valid move to avoid endless recycling.

## V11 execution update
- Foundation moves use two short taps (55 ms each) separated by 80 ms. This path is selected only for legal Foundation moves from a tableau card or the exposed Waste card.
- Tableau-to-tableau and Waste-to-tableau moves remain continuous drag gestures, with a 600 ms duration.
- Drag pickup is at the card header midpoint (`topY + 35`) and drop is at the target card midpoint (`targetY + 45`).
- Foundation and tableau legality helpers are centralized in `SolitaireEngine` and used by `BoardAnalyzer`.

## V14 movement and Draw-3 recovery
- Recalibrated tableau centers to X=68,166,264,362,460,558,655 on the 720x1640 reference frame. Each column OCR lane is 72 px wide and scans Y=580..1250.
- Tableau drags now start from the actual OCR position of the selected exposed sequence head and end at the actual exposed target card; a genuinely empty column uses Y=620. Source and target X coordinates use the fixed column centers.
- All tableau and waste-to-tableau moves use the continuous three-stage Accessibility gesture: Hold 120ms, Move 500ms, Hold 150ms. Foundation-only moves use double tap; stock draw uses a single tap.
- Draw-3 waste OCR scans X=430..605, Y=415..555, upscales the crop 3x, filters rank OCR to X=510..600 and Y=420..475, and selects the right-most rank glyph. The free-card touch point is X=565,Y=490; stock is X=655,Y=490.
- After a stock tap, analysis is held for at least 500ms so the deal animation can finish before the next OCR pass.
- Fixed a tableau occupancy regression: a lane with no detected face-up cards is no longer automatically marked as containing hidden cards based only on its column number. This allows legal King moves into empty columns.
- Reduced coordinate-only move suppression: the same source/target coordinates can be used again after the board changes; only immediate reverse drags are suppressed.
- The floating decision log is anchored at reference X=50,Y=1150 and displays the latest short action/status.
- Build and live-game execution still require verification through GitHub Actions and on the Android device. The archive has been integrity-checked; this environment did not complete a full Android Gradle build or live-game gesture test.
