package com.abouassi.jawakersolitairebot

import java.util.ArrayDeque

/** Strict Klondike rules and deterministic move priorities. All indices are zero-based. */
object SolitaireEngine {
    enum class Suit { HEARTS, DIAMONDS, CLUBS, SPADES }
    /** Color classification used by the OCR layer when the exact suit is not known. */
    enum class SuitColor { RED, BLACK }
    enum class Zone { TABLEAU, FOUNDATION, WASTE, STOCK }

    /** Empty Foundations accept only an Ace; later cards must be the next rank. */
    fun canMoveToFoundation(rank: Int, currentRank: Int): Boolean =
        if (currentRank == 0) rank == 1 else rank == currentRank + 1

    /** Tableau accepts alternating colours in descending order; only an empty column accepts K. */
    fun canStackOnTableau(
        movingRank: Int, movingColor: SuitColor,
        targetRank: Int?, targetColor: SuitColor?,
        targetCompletelyEmpty: Boolean
    ): Boolean = if (targetCompletelyEmpty) {
        movingRank == 13
    } else {
        targetRank != null && targetColor != null &&
            movingRank == targetRank - 1 && movingColor != targetColor
    }

    data class Card(val rank: Int, val suit: Suit) {
        init { require(rank in 1..13) }
        val isRed: Boolean get() = suit == Suit.HEARTS || suit == Suit.DIAMONDS
        fun canStackOn(other: Card): Boolean = isRed != other.isRed && rank == other.rank - 1
    }

    data class TableauColumn(val faceUp: List<Card>, val faceDownCount: Int) {
        init { require(faceDownCount >= 0) }
    }

    /** Foundation value is the highest rank already placed for that suit; 0 means empty. */
    data class Board(
        val columns: List<TableauColumn>,
        val foundations: Map<Suit, Int>,
        val waste: Card?,
        val stockAvailable: Boolean
    )

    data class Move(
        val fromZone: Zone,
        val fromColumn: Int = -1,
        val cardIndex: Int = -1,
        val toZone: Zone,
        val toColumn: Int = -1,
        val suit: Suit? = null,
        val reason: String,
        val score: Int,
        val movingRank: Int = -1
    )

    private const val HISTORY_LIMIT = 80
    private const val REPEAT_WINDOW = 24
    private val recentMoves = ArrayDeque<String>()
    private val recentSet = mutableSetOf<String>()

    /** Clear history only when a genuinely new game/board is started. */
    @Synchronized fun resetMoveMemory() {
        recentMoves.clear()
        recentSet.clear()
    }

    @Synchronized fun chooseMove(board: Board): Move? {
        if (board.columns.size != 7) return null
        val foundationMoves = mutableListOf<Move>()
        val tableauMoves = mutableListOf<Move>()
        val wasteMoves = mutableListOf<Move>()

        // Priority 1: exposed tableau cards to foundation. A vacant foundation accepts A only.
        board.columns.forEachIndexed { colIndex, col ->
            val cardIndex = col.faceUp.lastIndex
            if (cardIndex >= 0) {
                val card = col.faceUp[cardIndex]
                if (canMoveToFoundation(card, board)) {
                    foundationMoves += Move(Zone.TABLEAU, colIndex, cardIndex, Zone.FOUNDATION,
                        suit = card.suit, reason = "نقل إلى الأساس", score = 400,
                        movingRank = card.rank)
                }
            }
        }

        // Priority 2: tableau-to-tableau. Kings go ONLY to a completely empty tableau column.
        board.columns.forEachIndexed { fromIndex, source ->
            source.faceUp.forEachIndexed cardLoop@{ cardIndex, movingCard ->
                val suffix = source.faceUp.drop(cardIndex)
                if (!isValidDescendingAlternating(suffix)) return@cardLoop
                val revealsHidden = cardIndex == 0 && source.faceDownCount > 0
                board.columns.forEachIndexed targetLoop@{ toIndex, target ->
                    if (fromIndex == toIndex) return@targetLoop
                    val targetTop = target.faceUp.lastOrNull()
                    val targetIsCompletelyEmpty = target.faceUp.isEmpty() && target.faceDownCount == 0
                    val legal = if (targetIsCompletelyEmpty) movingCard.rank == 13
                                else targetTop != null && movingCard.canStackOn(targetTop)
                    if (legal) {
                        tableauMoves += Move(Zone.TABLEAU, fromIndex, cardIndex, Zone.TABLEAU,
                            toColumn = toIndex,
                            reason = if (revealsHidden) "كشف ورقة مخفية" else "ترتيب الأعمدة",
                            score = 300 + if (revealsHidden) 20 else 0,
                            movingRank = movingCard.rank)
                    }
                }
            }
        }

        // Priority 3: inspect the currently exposed Waste card on every board cycle.
        // It may advance its own foundation suit or move onto any legal tableau column.
        board.waste?.let { card ->
            if (canMoveToFoundation(card, board)) {
                wasteMoves += Move(Zone.WASTE, toZone = Zone.FOUNDATION, suit = card.suit,
                    reason = "نقل المخلفات إلى الأساس", score = 220, movingRank = card.rank)
            }
            board.columns.forEachIndexed { toIndex, target ->
                val targetTop = target.faceUp.lastOrNull()
                val targetIsCompletelyEmpty = target.faceUp.isEmpty() && target.faceDownCount == 0
                val legal = if (targetIsCompletelyEmpty) card.rank == 13
                            else targetTop != null && card.canStackOn(targetTop)
                if (legal) wasteMoves += Move(Zone.WASTE, toZone = Zone.TABLEAU,
                    toColumn = toIndex, reason = "نقل المخلفات إلى عمود", score = 190,
                    movingRank = card.rank)
            }
        }

        // Choose by strict priority tier, then avoid repeated/reversed moves within that tier.
        val selected = listOf(foundationMoves, tableauMoves, wasteMoves).firstNotNullOfOrNull { tier ->
            tier.sortedByDescending { it.score }.firstOrNull { !isLoop(it) }
        }
        if (selected != null) {
            remember(selected)
            return selected
        }

        // Priority 4: draw only when every legal move is exhausted or suppressed as a loop.
        if (board.stockAvailable) {
            val draw = Move(Zone.STOCK, toZone = Zone.WASTE,
                reason = "سحب ورقة جديدة", score = 1)
            remember(draw)
            return draw
        }
        return null
    }

    private fun canMoveToFoundation(card: Card, board: Board): Boolean {
        val current = board.foundations[card.suit] ?: 0
        return canMoveToFoundation(card.rank, current)
    }

    private fun isValidDescendingAlternating(cards: List<Card>): Boolean {
        if (cards.isEmpty()) return false
        return cards.zipWithNext().all { (upper, lower) ->
            upper.rank == lower.rank + 1 && upper.isRed != lower.isRed
        }
    }

    private fun signature(move: Move): String = listOf(
        move.fromZone.name, move.fromColumn, move.cardIndex, move.toZone.name,
        move.toColumn, move.suit?.name ?: "-", move.movingRank
    ).joinToString(":")

    private fun reverseSignature(move: Move): String = listOf(
        move.toZone.name, move.toColumn, move.cardIndex, move.fromZone.name,
        move.fromColumn, move.suit?.name ?: "-", move.movingRank
    ).joinToString(":")

    private fun isLoop(move: Move): Boolean {
        val key = signature(move)
        if (key in recentSet) return true
        // Do not bounce the same rank straight back between the same two columns.
        if (move.fromZone == Zone.TABLEAU && move.toZone == Zone.TABLEAU &&
            reverseSignature(move) in recentSet) return true
        return false
    }

    private fun remember(move: Move) {
        val key = signature(move)
        recentMoves.addLast(key)
        recentSet.add(key)
        while (recentMoves.size > HISTORY_LIMIT) {
            val old = recentMoves.removeFirst()
            if (old !in recentMoves) recentSet.remove(old)
        }
    }
}
