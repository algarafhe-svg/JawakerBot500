pluginManagement {
    repositories {
        gradlePluginPortal()
        mavenCentral()
        google()
        jcenter()
    }
}

dependencyResolutionManagement {
    repositoryStrategy = DependencyResolutionStrategy.ILA

    repositoriesMode = 'static'

    repositories {
        mavenCentral()
        google()
        maven { url = "https://maven.google.com" }
    }
}

rootProject.name = "Jawaker-Bot-APK"

include(":app")