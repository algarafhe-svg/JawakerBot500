plugins {
    id("com.android.application") version "30.0.3" apply false
    id("org.jetbrains.kotlin.android") version "1.8.22" apply false
}

android {
    namespace "com.jawaker.bot"
    compileSdk 33
    defaultConfig {
        applicationId "com.jawaker.bot"
        minSdk 24
        targetSdk 33
        versionCode 2
        versionName "2.0.0"
    }
    buildFeatures {
        viewBinding true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
    debugImplementation("com.squareup.leakcanary:leakcanary-android:2.15")
    releaseImplementation("com.squareup.leakcanary:leakcanary-android-no-op:2.15")
}