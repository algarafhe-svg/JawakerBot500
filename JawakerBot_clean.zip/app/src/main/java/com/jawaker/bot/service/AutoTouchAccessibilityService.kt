package com.jawaker.bot.service

import android.accessibilityservice.AccessibilityService
import android.gesture.GestureDescription
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.util.Log
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.jawaker.bot.JawakerAutoSolver.BotMove
import com.jawaker.bot.model.Card
import com.jawaker.bot.model.Rank
import com.jawaker.bot.model.Suit

/**
 * Accessibility service that performs automatic touches and drags for the auto-play bot.
 * NOW WITH: Alternative touch engine via ADB/shell input commands for emulator compatibility.
 */
class AutoTouchAccessibilityService(private val context: Context) : AccessibilityService() {

    private lateinit var handler: Handler
    private var currentMove: BotMove? = null
    private var isProcessingMove: Boolean = false
    private var accessibilityEnabled: Boolean = false

    // Visual touch point drawing
    private var touchPointPaint: Paint? = null
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var startPointTimer: Handler? = null
    private var endPointTimer: Handler? = null

    // Emulator 900x1600 at 320 DPI constants
    private val EMULATOR_WIDTH = 900
    private val EMULATOR_HEIGHT = 1600
    private val DENSITY_FACTOR = 2.0f

    // Touch circle data
    private data class TouchPoint(
        val x: Float,
        val y: Float,
        val label: String
    )

    init {
        handler = Handler(context.mainLooper)
        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        setupTouchPointPaints()
        checkAccessibilityEnabled()
    }

    private fun setupTouchPointPaints() {
        touchPointPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
            strokeWidth = 0f
        }
    }

    private fun checkAccessibilityEnabled() {
        try {
            val serviceInfo = packageManager
                .getServiceInfo(componentName, PackageManager.GET_META_DATA)
            accessibilityEnabled = true
        } catch (e: Exception) {
            accessibilityEnabled = false
        }
    }

    /**
     * Main entry point - perform a move based on BotMove description.
     * Tries dispatchGesture first, falls back to ADB/shell input commands.
     */
    fun performMove(move: BotMove?) {
        if (move == null || isProcessingMove) return

        // Check if accessibility is enabled
        if (!accessibilityEnabled) {
            checkAccessibilityEnabled()
            if (!accessibilityEnabled) {
                updateStatus("Error: Accessibility not enabled")
                return
            }
        }

        currentMove = move
        isProcessingMove = true

        try {
            when (move.type) {
                BotMove.Type.TAP -> performTapMove(move)
                BotMove.Type.DRAG -> performDragMove(move)
                BotMove.Type.FOUNDATION -> performFoundationMove(move)
                BotMove.Type.STOCK_TAP -> performStockTapMove()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to alternative touch method
            updateStatus("Fallback: Trying ADB input method")
            tryAlternativeTouch(move)
        } finally {
            isProcessingMove = false
            currentMove = null
        }
    }

    /**
     * Perform a tap move with gesture callback and visual feedback.
     * Single tap at card center with 40px downward offset from rank.
     */
    private fun performTapMove(move: BotMove) {
        val (x, y) = getTapPixels(move)
        val gesture = GestureDescription.Builder()

        // CRITICAL FIX for WebView/Canvas engines:
        // Move 4px to register the touch event
        val tapSpec = TouchGestureSpec(
            x.toFloat(),
            y.toFloat(),
            (x + 4f).toFloat(),
            (y + 4f).toFloat(),
            120
        )

        gesture.addStroke(tapSpec)

        // Pass gesture result callback for diagnostics
        dispatchGesture(gesture, object : onGestureEventListener {
            override fun onGestureEvent(event: Int) {
                // Intermediate events
            }
            override fun onCompleted(success: Boolean) {
                val statusChar = if (success) "(نجح)" else "(فشل)"
                val status = if (success) {
                    "✓ Tap successful at (${dpFromPx(x)}dp, ${dpFromPx(y)}dp) $statusChar"
                } else {
                    "✗ Tap FAILED at (${dpFromPx(x)}dp, ${dpFromPx(y)}dp) $statusChar"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
                // Show visual feedback
                showTouchFeedback(x, y, success)
                isProcessingMove = false
                currentMove = null
            }
        }, null)
    }

    /**
     * Alternative touch method using Android ADB/shell input commands.
     * Works when dispatchGesture is blocked by the emulator/game engine.
     */
    private fun tryAlternativeTouch(move: BotMove?) {
        if (move == null) return

        when (move.type) {
            BotMove.Type.TAP -> {
                // Get coordinates for stock pile tap (795, 345 in 900x1600)
                val (tapX, tapY) = when (move.card?.rank) {
                    null -> getStockPileCenterPixels()
                    else -> getTapPixels(move)
                }

                // Method 1: Try with su -c (root required)
                val method1Success = executeAdbCommand("shell input tap $tapX $tapY")

                // Method 2: Try without su (regular user)
                val method2Success = if (!method1Success) {
                    executeAdbCommand("input tap $tapX $tapY")
                } else false

                // Report result
                val status = if (method1Success) {
                    "✓ Stock tapped via su input tap"
                } else if (method2Success) {
                    "✓ Stock tapped via user input tap"
                } else {
                    "✗ All tap methods failed - Check: ADB permission, USB debugging, emulator settings"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
            }
            BotMove.Type.DRAG -> {
                // Execute swipe command
                val (startX, startY, endX, endY) = getDragPixels(move)
                executeAdbCommand("input swipe $startX $startY $endX $endY 350")
                updateStatus("✓ Executed ADB swipe command")
                Log.d("AutoTouchAS", "Executed ADB swipe: $startX,$startY -> $endX,$endY")
            }
            BotMove.Type.STOCK_TAP -> {
                // Stock pile tap via ADB
                val (tapX, tapY) = getStockPileCenterPixels()
                val success1 = executeAdbCommand("shell input tap $tapX $tapY")
                val success2 = if (!success1) executeAdbCommand("input tap $tapX $tapY") else false
                val status = if (success1 || success2) "✓ Stock tapped via ADB" else "✗ Stock tap ADB failed"
                updateStatus(status)
                Log.d("AutoTouchAS", status)
            }
        }
    }

    /**
     * Execute an ADB shell command via Runtime.
     * Returns true if the command was executed (may still fail on non-rooted emulator).
     */
    private fun executeAdbCommand(command: String): Boolean {
        try {
            // Try with su prefix first (for rooted emulators)
            val process1 = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            process1.waitFor()

            // If su not available, try without su
            val process2 = Runtime.getRuntime().exec(command)
            process2.waitFor()

            // Command executed successfully (exit value 0)
            val success = process1.exitValue() == 0 || process2.exitValue() == 0
            if (success) Log.d("AutoTouchAS", "ADB command executed: $command")
            return success
        } catch (e: Exception) {
            Log.e("AutoTouchAS", "Failed to execute ADB command: $command", e)
            return false
        }
    }

    /**
     * Get stock pile center pixels for 900x1600 emulator.
     */
    private fun getStockPileCenterPixels(): Pair<Int, Int> {
        Pair(795, 345)
    }

    /**
     * Get tap coordinates with proper offset from card rank text.
     * Offset downward by 80px (40dp at 320dpi) to grab card body.
     */
    private fun getTapPixels(move: BotMove): Pair<Float, Float> {
        return when (move.type) {
            BotMove.Type.TAP, BotMove.Type.FOUNDATION -> {
                val offsetY = 80f // 40dp * 2.0f density factor
                val baseX = (move.startX ?: 0f + move.endX ?: 0f) / 2
                val baseY = (move.startY ?: 0f + move.endY ?: 0f) / 2
                Pair(baseX, baseY + offsetY)
            }
            BotMove.Type.STOCK_TAP -> {
                Pair(795f, 345f) // Exact stock pile center in 900x1600
            }
            else -> Pair(0f, 0f)
        }
    }

    /**
     * Get drag pixels in PIXELS for 900x1600 emulator.
     */
    private fun getDragPixels(move: BotMove): FourFloatPair {
        return when (move.type) {
            BotMove.Type.DRAG -> {
                val startX = move.startX ?: 0f
                val startY = move.startY ?: 0f
                val endX = move.endX ?: 0f
                val endY = move.endY ?: 0f
                // Clamp to emulator bounds
                val clampedStartX = startX.coerceAtLeast(0f).coerceAtMost(EMULATOR_WIDTH.toFloat())
                val clampedStartY = startY.coerceAtLeast(0f).coerceAtMost(EMULATOR_HEIGHT.toFloat())
                val clampedEndX = endX.coerceAtLeast(0f).coerceAtMost(EMULATOR_WIDTH.toFloat())
                val clampedEndY = endY.coerceAtLeast(0f).coerceAtMost(EMULATOR_HEIGHT.toFloat())
                FourFloatPair(clampedStartX, clampedStartY, clampedEndX, clampedEndY)
            }
            else -> FourFloatPair(0f, 0f, 0f, 0f)
        }
    }

    private data class FourFloatPair(
        val startX: Float,
        val startY: Float,
        val endX: Float,
        val endY: Float
    )

    private data class TouchGestureSpec(
        val startX: Float,
        val startY: Float,
        val endX: Float? = null,
        val endY: Float? = null,
        val duration: Int = 300
    )

    /**
     * Update the status text in the floating overlay.
     */
    private fun updateStatus(message: String) {
        try {
            // This would need access to the floating view's TextView
            // For now, just log
            Log.d("AutoTouchAS", message)
        } catch (e: Exception) {
            Log.e("AutoTouchAS", "Failed to update status", e)
        }
    }

    private fun dpFromPx(px: Float): Float {
        return px / DENSITY_FACTOR
    }

    private interface onGestureEventListener {
        fun onGestureEvent(event: Int)
        fun onCompleted(success: Boolean)
    }
}