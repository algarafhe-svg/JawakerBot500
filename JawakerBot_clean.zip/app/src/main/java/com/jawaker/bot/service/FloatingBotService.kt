package com.jawaker.bot.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.os.Handler
import android.view.View
import android.view.View.OnTouchListener
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.jawaker.bot.JawakerAutoSolver.BotMove
import com.jawaker.bot.model.Card
import com.jawaker.bot.model.Rank
import com.jawaker.bot.model.Suit

/**
 * Floating Bot Service - Main service orchestrator for Jawaker Auto-Play Bot.
 * NOW WITH: Visual calibration overlay system and multi-method touch engine.
 */
class FloatingBotService : Service() {

    private var mFloatingView: View? = null
    private var mParams: WindowManager.LayoutParams? = null
    private var mIsRunning: Boolean = false
    private var mIsPaused: Boolean = false
    private var mLastMoveTime: Long = 0

    // Emulator 900x1600 at 320 DPI constants
    private val EMULATOR_WIDTH = 900
    private val EMULATOR_HEIGHT = 1600
    private val DENSITY_FACTOR = 2.0f

    // Calibration mode state
    private var mIsCalibrating: Boolean = false
    private var mCalibrationCircles: MutableList<CalibrationCircle> = mutableListOf()
    private var mSelectedCircle: CalibrationCircle? = null

    // SharedPreferences keys for saved calibration
    private val PREFS_NAME = "JawakerCalibrationPrefs"
    private val PREFS_CIRCLES = "calibration_circles_json"

    // UI references
    private var mCalibrationOverlay: View? = null
    private var mCirclesContainer: View? = null
    private var mStatusText: TextView? = null
    private var mTapCount: Int = 0

    // Touch tracking for calibration
    private var mLastTouchX: Float = 0f
    private var mLastTouchY: Float = 0f
    private var mMoveStartX: Float = 0f
    private var mMoveStartY: Float = 0f
    private var mIsDragging: Boolean = false
    private var mLongPressDetector: Handler? = null

    // Touch circle data class
    private data class CalibrationCircle(
        val id: String,
        var x: Float,
        var y: Float,
        val color: Int,
        val label: String,
        var isDragging: Boolean = false
    )

    // Initialize calibration circles at correct positions (will be overridden by user)
    private val defaultCalibrationCircles: List<CalibrationCircle> = listOf(
        // Stock Pile: X=795, Y=345
        CalibrationCircle("STOCK", 795f, 345f, Color.YELLOW, "STOCK"),
        // Waste Pile: X=635, Y=345 (middle of 560-710 range)
        CalibrationCircle("WASTE", 635f, 345f, Color.BLUE, "WASTE"),
        // Foundations: 4 slots from X=115 to X=485
        CalibrationCircle("F1", 115f, 345f, Color.GREEN, "F1"),
        CalibrationCircle("F2", 235f, 345f, Color.GREEN, "F2"),
        CalibrationCircle("F3", 355f, 345f, Color.GREEN, "F3"),
        CalibrationCircle("F4", 475f, 345f, Color.GREEN, "F4"),
        // Tableau Columns 7 centers: 95, 215, 335, 450, 565, 685, 805
        CalibrationCircle("C1", 95f, 475f, Color.RED, "C1"),
        CalibrationCircle("C2", 215f, 475f, Color.RED, "C2"),
        CalibrationCircle("C3", 335f, 475f, Color.RED, "C3"),
        CalibrationCircle("C4", 450f, 475f, Color.RED, "C4"),
        CalibrationCircle("C5", 565f, 475f, Color.RED, "C5"),
        CalibrationCircle("C6", 685f, 475f, Color.RED, "C6"),
        CalibrationCircle("C7", 805f, 475f, Color.RED, "C7")
    )

    override fun onCreate() {
        super.onCreate()
        initializeComponents()
        // Set the final v2.0 title
        setFloatingTitle("JAWAKER BOT v2.0")
    }

    private fun initializeComponents() {
        mStatusText = findViewById<View>(R.id.txt_status) as? TextView

        // Load saved calibration or use defaults
        val savedCalibration = loadSavedCalibration()
        // We have 13 circles: STOCK(1) + WASTE(1) + F1-F4(4) + C1-C7(7) = 13 circles
        mCalibrationCircles = if (savedCalibration != null && savedCalibration.size == 13) {
            savedCalibration
        } else {
            defaultCalibrationCircles
        }

        // Inflate the floating layout
        val inflater = LayoutInflater.from(this)
        mFloatingView = inflater.inflate(R.layout.overlay_bot, null)

        mParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )

        mParams!!.gravity = Gravity.BOTTOM or Gravity.START
        mParams!!.x = 0f
        mParams!!.y = 0f
        mParams!!.width = WindowManager.LayoutParams.MATCH_PARENT
        mParams!!.height = WindowManager.LayoutParams.WRAP_CONTENT
        mParams!!.windowAnimations = 0

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.addView(mFloatingView, mParams)

        // Set up click listeners
        setupClickListeners()

        // Initialize calibration overlay
        initCalibrationOverlay()

        // Update status
        updateStatus("Jawaker Bot v2.0 - Ready")
    }

    private fun setupClickListeners() {
        val btnStart = mFloatingView?.findViewById<View>(R.id.btn_start) as? Button
        val btnPause = mFloatingView?.findViewById<View>(R.id.btn_pause) as? Button
        val btnCalibrate = mFloatingView?.findViewById<View>(R.id.btn_calibrate) as? Button
        val btnCalibrateOverlay = mFloatingView?.findViewById<View>(R.id.btn_calibrate_overlay) as? Button

        btnStart?.setOnClickListener {
            mIsRunning = true
            mIsPaused = false
            updateStatus("Status: Running")
        }

        btnPause?.setOnClickListener {
            mIsPaused = !mIsPaused
            updateStatus(if (mIsPaused) "Status: Paused" else "Status: Running")
        }

        btnCalibrate?.setOnClickListener {
            // Start bot operation
            updateStatus("Status: Running")
        }

        // CRITICAL: Calibrate Places button - shows drag circles
        btnCalibrateOverlay?.setOnClickListener {
            toggleCalibrationMode()
        }

        // Test Tap button - taps stock pile at exact coordinates (795, 345)
        val btnTestTap = mFloatingView?.findViewById<View>(R.id.btn_test_tap) as? Button
        btnTestTap?.setOnClickListener {
            executeStockTapViaAlternative()
        }
    }

    /**
     * Toggle calibration mode - show draggable circles over the game
     */
    private fun toggleCalibrationMode() {
        mIsCalibrating = !mIsCalibrating

        if (mIsCalibrating) {
            showCalibrationOverlay()
            updateStatus("Calibration Mode: Drag circles to correct positions\nSTOCK=Yellow, WASTE=Blue, F1-F4=Green, C1-C7=Red")
        } else {
            hideCalibrationOverlay()
            saveCalibration()
            updateStatus("Calibration Saved - Using stored coordinates")
            Log.d("FloatingBot", "Calibration saved: ${mCalibrationCircles.size} circles")
        }
    }

    private fun initCalibrationOverlay() {
        mCalibrationOverlay = mFloatingView?.findViewById<View>(R.id.calibration_overlay) as? View
        mCirclesContainer = mFloatingView?.findViewById<View>(R.id.circles_container) as? View

        // Set up layout parameters for the overlay
        val overlayParams = mCalibrationOverlay?.layoutParams as? FrameLayout.LayoutParams
        overlayParams?.width = WindowManager.LayoutParams.MATCH_PARENT
        overlayParams?.height = WindowManager.LayoutParams.MATCH_PARENT

        // Generate calibration circles
        generateCalibrationCircles()
    }

    private fun generateCalibrationCircles() {
        // Remove existing circles
        mCirclesContainer?.removeAllViewsInLayout()

        mCalibrationCircles.forEach { circle ->
            val circleView = View(context).apply {
                // Circle diameter: 40dp = 80px at 320 DPI
                val diameter_px = 80f
                setMinimumWidth(diameter_px.toInt())
                setMinimumHeight(diameter_px.toInt())

                // Set colors based on circle type
                background = ColorDrawable(circle.color)

                // Make view clickable and set up touch listener
                setOnTouchListener { v, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            mSelectedCircle = circle
                            mIsDragging = true
                            mMoveStartX = event.rawX
                            mMoveStartY = event.rawY
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            if (mIsDragging && mSelectedCircle != null) {
                                // Move the circle with finger/ mouse
                                mSelectedCircle.x = event.rawX - diameter_px / 2
                                mSelectedCircle.y = event.rawY - diameter_px / 2
                                // Keep within screen bounds
                                mSelectedCircle.x = mSelectedCircle.x.coerceAtLeast(0f).coerceAtMost(EMULATOR_WIDTH.toFloat() - diameter_px)
                                mSelectedCircle.y = mSelectedCircle.y.coerceAtLeast(0f).coerceAtMost(EMULATOR_HEIGHT.toFloat() - diameter_px)
                                // Update view position
                                val params = v.layoutParams as? FrameLayout.LayoutParams
                                params?.x = mSelectedCircle.x.toInt()
                                params?.y = mSelectedCircle.y.toInt()
                                v.layoutParams = params
                                v.invalidate()
                            }
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            mIsDragging = false
                            mSelectedCircle = null
                            // Could auto-detect position here, but we'll wait for Save
                            true
                        }
                        else -> false
                    }
                }

                // Set initial position
                val circleParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                circleParams.x = circle.x.toInt()
                circleParams.y = circle.y.toInt()
                v.layoutParams = circleParams

                // Add touch listener for moving
                v.setOnTouchListener { v, event ->
                    // Handled above in the view's touch listener
                    true
                }

                mCirclesContainer?.addView(v)
            }
        }
    }

    /**
     * Save calibration coordinates to SharedPreferences
     */
    private fun saveCalibration() {
        val json = mCalibrationCircles.joinToString(",") {
            "${it.id}:${it.x}:${it.y}"
        }
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREFS_CIRCLES, json).apply()

        Log.d("FloatingBot", "Saved calibration: ${mCalibrationCircles.joinToString(", ")}")
    }

    /**
     * Load saved calibration from SharedPreferences
     */
    private fun loadSavedCalibration(): List<CalibrationCircle>? {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(PREFS_CIRCLES, null)

        if (json != null) {
            return json.split(",").map { part ->
                val parts = part.split(":")
                if (parts.size >= 3) {
                    CalibrationCircle(
                        id = parts[0],
                        x = parts[1].toFloat(),
                        y = parts[2].toFloat(),
                        color = when (parts[0]) {
                            "STOCK" -> Color.YELLOW
                            "WASTE" -> Color.BLUE
                            "F1", "F2", "F3", "F4" -> Color.GREEN
                            "C1", "C2", "C3", "C4", "C5", "C6", "C7" -> Color.RED
                            else -> Color.WHITE
                        },
                        label = parts[0]
                    )
                } else null
            }.filter { it.id != null }
        }
        return null
    }

    private fun hideCalibrationOverlay() {
        mCalibrationOverlay?.visibility = View.GONE
        mCirclesContainer?.removeAllViewsInLayout()
    }

    private fun showCalibrationOverlay() {
        mCalibrationOverlay?.visibility = View.VISIBLE
        // Initialize circles at default positions first
        generateCalibrationCircles()
    }

    /**
     * Perform a move based on BotMove description.
     * Uses saved calibration coordinates if available.
     */
    fun performMove(move: BotMove?) {
        if (move == null || isProcessingMove) return

        // Check if accessibility is enabled
        if (!accessibilityEnabled) {
            checkAccessibilityEnabled()
            if (!accessibilityEnabled) {
                updateStatus("Error: Accessibility not enabled")
                return
            }
        }

        currentMove = move
        isProcessingMove = true

        try {
            when (move.type) {
                BotMove.Type.TAP -> performTapMove(move)
                BotMove.Type.DRAG -> performDragMove(move)
                BotMove.Type.FOUNDATION -> performFoundationMove(move)
                BotMove.Type.STOCK_TAP -> performStockTapMove()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            updateStatus("Error: Move execution failed")
            isProcessingMove = false
            currentMove = null
        }
    }

    // ... rest of the service methods would continue here
    // For brevity, I'm showing the key additions

    private fun updateStatus(message: String) {
        mStatusText?.text = message
    }

    /**
     * Set the floating window title
     */
    private fun setFloatingTitle(title: String) {
        try {
            // Try to find a title view in the floating layout
            val titleView = mFloatingView?.findViewById<View>(R.id.txt_status) as? TextView
            if (titleView != null) {
                titleView.text = title
            }
        } catch (e: Exception) {
            Log.e("FloatingBot", "Failed to set title: ${e.message}")
        }
    }

    /**
     * Execute stock pile tap via ADB/shell alternative methods.
     * Tries su -c first, then regular user, with status updates.
     */
    private fun executeStockTapViaAlternative() {
        val (tapX, tapY) = getStockPileCenterPixels()
        updateStatus("Attempting stock tap at ($tapX, $tapY) via alternative methods...")

        // Method 1: Try with su -c (root required for emulator system commands)
        val method1Success = try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "input tap $tapX $tapY"))
            process.waitFor(3000)
            process.exitValue() == 0
        } catch (e: Exception) {
            false
        }

        // Method 2: Try without su (regular user)
        val method2Success = if (method1Success) {
            true
        } else {
            try {
                val process = Runtime.getRuntime().exec("input tap $tapX $tapY")
                process.waitFor(3000)
                process.exitValue() == 0
            } catch (e: Exception) {
                false
            }
        }

        // Report result
        val status = when {
            method1Success -> "✓ Stock tapped via su input tap at ($tapX, $tapY)"
            method2Success -> "✓ Stock tapped via user input tap at ($tapX, $tapY)"
            else -> "✗ All tap methods failed for stock at ($tapX, $tapY)\nCheck: ADB enabled, USB debugging, emulator permissions"
        }
        updateStatus(status)
        Log.d("FloatingBot", status)
        Toast.makeText(this, status, Toast.LENGTH_LONG).show()
    }

    private fun checkAccessibilityEnabled() {
        try {
            val serviceInfo = packageManager
                .getServiceInfo(componentName, PackageManager.GET_META_DATA)
            accessibilityEnabled = true
        } catch (e: Exception) {
            accessibilityEnabled = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mFloatingView != null) {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            wm.removeView(mFloatingView)
        }
        // Save calibration on destroy
        saveCalibration()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}