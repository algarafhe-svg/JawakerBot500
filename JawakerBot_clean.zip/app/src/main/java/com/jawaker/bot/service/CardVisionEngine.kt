package com.jawaker.bot.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.jawaker.bot.model.Card
import com.jawaker.bot.model.Rank
import com.jawaker.bot.model.Suit
import com.jawaker.bot.service.FloatingBotService.CalibrationCircle

/**
 * Engine that processes screen capture data and provides structured game state
 * for the auto-solver to make decisions.
 * FIXED COORDINATES for Emulator 900x1600 at 320 DPI (density=2.0f, 1dp=2px).
 * All coordinates are in PIXELS, not percentages.
 *
 * Default calibration circles used when no saved calibration is available.
 */
class CardVisionEngine {

    // ========================================
    // EMULATOR 900x1600 at 320 DPI (xhdpi)
    // ========================================
    // Density factor: 2.0f (1dp = 2px)
    // Derived pixel coordinates from original percentages:
    // Original: 1080x1920 -> percentages work fine
    // Emulator: 900x1600 -> must use absolute pixels

    // Default calibration circles used when no saved calibration is available
    // These match the positions in FloatingBotService
    private val defaultCalibrationCircles: List<CalibrationCircle> = listOf(
        // Stock Pile: X=795, Y=345
        CalibrationCircle("STOCK", 795f, 345f, Color.YELLOW, "STOCK"),
        // Waste Pile: X=635, Y=345 (middle of 560-710 range)
        CalibrationCircle("WASTE", 635f, 345f, Color.BLUE, "WASTE"),
        // Foundations: 4 slots from X=115 to X=485
        CalibrationCircle("F1", 115f, 345f, Color.GREEN, "F1"),
        CalibrationCircle("F2", 235f, 345f, Color.GREEN, "F2"),
        CalibrationCircle("F3", 355f, 345f, Color.GREEN, "F3"),
        CalibrationCircle("F4", 475f, 345f, Color.GREEN, "F4"),
        // Tableau Columns 7 centers: 95, 215, 335, 450, 565, 685, 805
        CalibrationCircle("C1", 95f, 475f, Color.RED, "C1"),
        CalibrationCircle("C2", 215f, 475f, Color.RED, "C2"),
        CalibrationCircle("C3", 335f, 475f, Color.RED, "C3"),
        CalibrationCircle("C4", 450f, 475f, Color.RED, "C4"),
        CalibrationCircle("C5", 565f, 475f, Color.RED, "C5"),
        CalibrationCircle("C6", 685f, 475f, Color.RED, "C6"),
        CalibrationCircle("C7", 805f, 475f, Color.RED, "C7")
    )

    // Screen dimensions in pixels
    private val SCREEN_WIDTH = 900
    private val SCREEN_HEIGHT = 1600

    // ========================================
    // FOUNDATIONS (4 slots) - Top area
    // ========================================
    // Layout: A A A A from left to right
    // X range: 115px to 485px (total 370px for 4 slots = ~92.5px per slot)
    // Y position: 345px (middle of foundation row)
    private val FOUNDATIONS_Y = 345
    private val FOUNDATIONS_START_X = 115
    private val FOUNDATION_SLOT_WIDTH = 92  // approximate slot width
    private val FOUNDATION_SLOT_GAP = 2     // small gap between slots

    // ========================================
    // STOCK PILE - Right side
    // ========================================
    // Exact center: X = 795px, Y = 345px
    private val STOCK_PILE_CENTER_X = 795
    private val STOCK_PILE_CENTER_Y = 345

    // ========================================
    // WASTE PILE - Left of stock
    // ========================================
    // X range: 560px to 710px
    // Y position: 345px
    private val WASTE_LEFT_X = 560
    private val WASTE_RIGHT_X = 710
    private val WASTE_Y = 345

    // ========================================
    // TABLEAU COLUMNS 1-7
    // ========================================
    // Start Y: 470px, End Y: 1350px
    // Column centers X positions (px):
    private val TABLEAU_START_Y = 470
    private val TABLEAU_END_Y = 1350
    private val TABLEAU_COLUMN_COUNT = 7

    // Column center X positions (exact pixels):
    // Col 1: 95, Col 2: 215, Col 3: 335, Col 4: 450, Col 5: 565, Col 6: 685, Col 7: 805
    private val TABLEAU_COLUMN_X = arrayOf(
        95,       // Column 1
        215,      // Column 2
        335,      // Column 3
        450,      // Column 4
        565,      // Column 5
        685,      // Column 6
        805       // Column 7
    )

    // Each column has a vertical range
    // Approximate: each card is ~60px tall, with ~70 cards max per column
    // But we just need the detection region

    /**
     * Analyze screen bitmap and extract structured game state
     * using EXACT pixel coordinates for 900x1600 emulator.
     * Bitmap MUST be 900x1600 pixels (will scale if different).
     */
    fun analyzeScreen(bitmap: Bitmap): GameState {
        // Ensure bitmap is correct size - scale if needed
        val scaledBitmap = ensureCorrectSize(bitmap)

        val gameState = GameState()

        // 1. Detect Foundations (4 slots)
        detectFoundations(scaledBitmap, gameState)

        // 2. Detect Stock Pile
        detectStockPile(scaledBitmap, gameState)

        // 3. Detect Waste Pile
        detectWastePile(scaledBitmap, gameState)

        // 4. Detect Tableau Columns 1-7
        detectTableauColumns(scaledBitmap, gameState)

        return gameState
    }

    /**
     * Ensure bitmap is 900x1600 - scale if original capture has different dimensions.
     */
    private fun ensureCorrectSize(bitmap: Bitmap): Bitmap {
        if (bitmap.width == SCREEN_WIDTH && bitmap.height == SCREEN_HEIGHT) {
            return bitmap
        }
        // Scale bitmap to exact emulator dimensions
        return Bitmap.createScaledBitmap(bitmap, SCREEN_WIDTH, SCREEN_HEIGHT, true)
    }

    /**
     * Detect Foundations area: 4 slots using calibration circle positions
     */
    private fun detectFoundations(bitmap: Bitmap, gameState: GameState, circles: List<CalibrationCircle>) {
        gameState.foundationPiles = emptyList() // Initialize

        // Create 4 foundation slots using calibration
        val slots = mutableListOf<CardVisionEngine.FoundationSlot>()

        // Find the STOCK circle to get reference position, then calculate foundations from there
        // In Jawaker, foundations are typically to the right of stock, but we use defaults if no circle found
        var referenceX = FOUNDATIONS_START_X
        var referenceY = FOUNDATIONS_Y

        for (circle in circles) {
            if (circle.id == "STOCK") {
                referenceX = circle.x.toInt()
                referenceY = circle.y.toInt()
                break
            }
        }

        // Calculate foundation slot positions relative to reference point
        for (slotIndex in 0 until 4) {
            // Use calibration if available, otherwise default positions
            val slotX = if (circles.any { it.id == "F${slotIndex + 1}" }) {
                circles.find { it.id == "F${slotIndex + 1}" }!!.x.toInt()
            } else {
                referenceX + (slotIndex * (FOUNDATION_SLOT_WIDTH + FOUNDATION_SLOT_GAP)) + (FOUNDATION_SLOT_WIDTH / 2)
            }
            val slotY = if (circles.any { it.id == "F${slotIndex + 1}" }) {
                circles.find { it.id == "F${slotIndex + 1}" }!!.y.toInt()
            } else {
                FOUNDATIONS_Y
            }

            // Sample region around the foundation slot center
            // Horizontal range: ±40px from center, Vertical range: ±30px from Y=345
            val regionLeft = Math.max(0, slotX - 40)
            val regionRight = Math.min(SCREEN_WIDTH, slotX + 40)
            val regionTop = Math.max(0, slotY - 30)
            val regionBottom = Math.min(SCREEN_HEIGHT, slotY + 30)

            val region = Rect(regionLeft, regionTop, regionRight, regionBottom)
            val cardsInSlot = analyzeColorRegionForCards(bitmap, region)

            slots.add(CardVisionEngine.FoundationSlot(
                suit = determineFoundationSuit(slotIndex), // Position-based suit assignment
                cards = cardsInSlot
            ))
        }

        gameState.foundationPiles = slots
    }

    /**
     * Determine suit for foundation slot based on position order.
     * In Jawaker: typically Hearts, Diamonds, Spades, Clubs from left to right,
     * or some other fixed order. This is a placeholder.
     */
    private fun determineFoundationSuit(slotIndex: Int): Suit {
        return when (slotIndex) {
            0 -> Suit.HEARTS
            1 -> Suit.DIAMONDS
            2 -> Suit.SPADES
            3 -> Suit.CLUBS
            else -> Suit.HEARTS
        }
    }

    /**
     * Detect Stock Pile using calibration circle position
     */
    private fun detectStockPile(bitmap: Bitmap, gameState: GameState, circles: List<CalibrationCircle>) {
        // Use saved calibration position if available, otherwise default
        val stockCircle = circles.find { it.id == "STOCK" }
        val centerX = stockCircle?.x?.toInt() ?: STOCK_PILE_CENTER_X
        val centerY = stockCircle?.y?.toInt() ?: STOCK_PILE_CENTER_Y

        // Sample region around stock pile center: ±30px radius
        val regionLeft = Math.max(0, centerX - 30)
        val regionRight = Math.min(SCREEN_WIDTH, centerX + 30)
        val regionTop = Math.max(0, centerY - 30)
        val regionBottom = Math.min(SCREEN_HEIGHT, centerY + 30)

        val region = Rect(regionLeft, regionTop, regionRight, regionBottom)
        val cardsInRegion = analyzeColorRegionForCards(bitmap, region)

        gameState.stockPileCards = cardsInRegion
    }

    /**
     * Detect Waste Pile using calibration circle position
     */
    private fun detectWastePile(bitmap: Bitmap, gameState: GameState, circles: List<CalibrationCircle>) {
        // Use saved calibration position if available, otherwise default
        val wasteCircle = circles.find { it.id == "WASTE" }
        val centerX = wasteCircle?.x?.toInt() ?: WASTE_LEFT_X + (WASTE_RIGHT_X - WASTE_LEFT_X) / 2
        val centerY = wasteCircle?.y?.toInt() ?: WASTE_Y

        // Sample the full waste pile width using calibration X range
        val regionLeft = if (wasteCircle != null) {
            // Use calibrated width range or default 560-710
            centerX - 75  // half-width from center
        } else {
            WASTE_LEFT_X
        }
        val regionRight = if (wasteCircle != null) {
            centerX + 75
        } else {
            WASTE_RIGHT_X
        }
        val regionTop = Math.max(0, centerY - 25)
        val regionBottom = Math.min(SCREEN_HEIGHT, centerY + 25)

        val region = Rect(regionLeft, regionTop, regionRight, regionBottom)
        val cardsInRegion = analyzeColorRegionForCards(bitmap, region)

        // Waste pile top card is the first/primary card detected
        gameState.wastePileTopCard = if (cardsInRegion.isNotEmpty()) {
            cardsInRegion.firstOrNull()
        } else null
    }

    /**
     * Detect Tableau Columns 1-7 using calibration circle positions
     */
    private fun detectTableauColumns(bitmap: Bitmap, gameState: GameState, circles: List<CalibrationCircle>) {
        gameState.tableauColumns = emptyList()

        // Find column reference from calibration - use C1 position as reference
        val c1Circle = circles.find { it.id == "C1" }
        var referenceX = TABLEAU_COLUMN_X[0]  // default 95
        var referenceY = TABLEAU_START_Y

        if (c1Circle != null) {
            referenceX = c1Circle.x.toInt()
            referenceY = c1Circle.y.toInt()
        }

        for (colIndex in 0 until TABLEAU_COLUMN_COUNT) {
            // Use calibration position if available, otherwise default positions
            val colCenterX = if (circles.any { it.id == "C${colIndex + 1}" }) {
                circles.find { it.id == "C${colIndex + 1}" }!!.x.toInt()
            } else {
                // Calculate from reference: columns are spaced 120px apart
                referenceX + (colIndex * 120)
            }
            val colCenterY = if (circles.any { it.id == "C${colIndex + 1}" }) {
                circles.find { it.id == "C${colIndex + 1}" }!!.y.toInt()
            } else {
                referenceY
            }

            // Calculate column detection region
            // Horizontal: ±35px from center, Vertical: from START_Y to END_Y
            val regionLeft = Math.max(0, colCenterX - 35)
            val regionRight = Math.min(SCREEN_WIDTH, colCenterX + 35)
            val regionTop = TABLEAU_START_Y
            val regionBottom = TABLEAU_END_Y

            val region = Rect(regionLeft, regionTop, regionRight, regionBottom)
            val cardsInColumn = analyzeColorRegionForCards(bitmap, region)

            // Determine top card position within this column
            // The top-most card is typically the first detected going upward from START_Y
            var topCardY = TABLEAU_END_Y // Start from bottom, find highest card
            if (cardsInColumn.isNotEmpty()) {
                // For now, set approximate top position slightly below start
                topCardY = TABLEAU_START_Y + 20
            }

            gameState.tableauColumns.add(CardVisionEngine.TableauColumn(
                columnIndex = colIndex + 1,
                cards = cardsInColumn,
                topCardPosition = Pair(colCenterX.toFloat(), topCardY.toFloat())
            ))
        }
    }

    /**
     * Analyze a color region for card detection using pixel color analysis.
     * Returns list of detected cards in this region.
     */
    private fun analyzeColorRegionForCards(bitmap: Bitmap, region: Rect): List<Card> {
        val resultCards = mutableListOf<Card>()

        // Ensure region is within bitmap bounds
        val clampedLeft = Math.max(0, region.left)
        val clampedRight = Math.min(SCREEN_WIDTH, region.right)
        val clampedTop = Math.max(0, region.top)
        val clampedBottom = Math.min(SCREEN_HEIGHT, region.bottom)

        if (clampedLeft >= clampedRight || clampedTop >= clampedBottom) {
            return resultCards
        }

        // Get the actual sub-region from bitmap (bitmap should be 900x1600)
        val regionWidth = clampedRight - clampedLeft
        val regionHeight = clampedBottom - clampedTop

        if (regionWidth <= 0 || regionHeight <= 0) return resultCards

        // Sample pixels across the region
        // Use a grid sample - 1 point per ~50 pixels for performance
        val sampleStep = maxOf(1, min(regionWidth, regionHeight) / 4)

        var redCount = 0
        var blueCount = 0
        var blackCount = 0

        for (x in clampedLeft until clampedRight step sampleStep) {
            for (y in clampedTop until clampedBottom step sampleStep) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel and 0x00FF0000) >> 16
                val g = (pixel and 0x0000FF00) >> 8
                val b = pixel and 0x000000FF

                // Color classification for suits
                // Hearts/Diamonds: high red, low green/blue
                // Spades/Clubs: high blue/black, low red

                if (r > 150 && g < 100 && b < 100) {
                    // Red region - likely Hearts or Diamonds
                    redCount++
                } else if (r < 100 && b > 150 && g < 100) {
                    // Blue region - likely Spades
                    blueCount++
                } else if (r < 50 && b > 150 && g < 50) {
                    // Dark blue/black - likely Clubs
                    blackCount++
                }
            }
        }

        // Determine dominant suit color
        val dominantColor = when {
            redCount > blueCount + blackCount && redCount > 3 -> "red"   // Hearts or Diamonds
            blueCount > blackCount && blueCount > 3 -> "black"          // Spades or Clubs
            else -> "unknown"
        }

        // If we have significant color detection, create a placeholder card
        // In full implementation, would use ML Kit OCR for exact rank
        if (redCount > 3 || blueCount > 3 || blackCount > 3) {
            // Create a card with generic rank based on color dominance
            val rank = when {
                redCount > blueCount + blackCount -> Rank.ACE // Placeholder for red suit cards
                blueCount > blackCount -> Rank.KING // Placeholder for black suit cards
                else -> Rank.TWO
            }
            val suit = when (dominantColor) {
                "red" -> when (blueCount > redCount) Suit.CLUBS else Suit.HEARTS
                "black" -> when (blueCount > redCount) Suit.SPADES else Suit.CLUBS
                else -> Suit.HEARTS
            }
            resultCards.add(Card(rank, suit))
        }

        return resultCards
    }

    /**
     * Game state container holding all detected game elements
     */
    data class GameState(
        /** Cards in the stock pile (right side, Y=345) */
        var stockPileCards: List<Card> = emptyList(),
        /** Top card visible in waste pile (X=560-710, Y=345) */
        var wastePileTopCard: Card? = null,
        /** Foundation piles - 4 slots top area (X=115-485, Y=345) */
        var foundationPiles: List<FoundationSlot> = emptyList(),
        /** Tableau columns - 7 columns, X positions exact, Y=470-1350 */
        var tableauColumns: List<TableauColumn> = emptyList()
    )

    data class FoundationSlot(
        /** The suit of this foundation pile (inferred from position order) */
        var suit: Suit? = null,
        /** Cards added to this pile, top is last */
        var cards: List<Card> = emptyList()
    )

    data class TableauColumn(
        /** The column index (1-7) */
        var columnIndex: Int = 1,
        /** Cards in this column from bottom to top */
        var cards: List<Card> = emptyList(),
        /** The top-most visible card position (X, Y coordinates in pixels) */
        var topCardPosition: Pair<Float, Float> = Pair(0f, 0f)
    )