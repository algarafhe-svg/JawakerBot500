package com.jawaker.bot.model

/**
 * Replay playing card with rank and suit.
 */
data class Card(
    /** The rank of the card (A, 2, 3, ..., K) */
    val rank: Rank,
    /** The suit of the card (hearts, diamonds, spades, clubs) */
    val suit: Suit