package com.jawaker.bot.model

/**
 * Enum representing card ranks from Ace to King.
 */
enum class Rank {
    ACE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN,
    JACK,
    QUEEN,
    KING
}

/**
 * Extension property to get the ordinal position of a rank.
 * Useful for comparison operations.
 */
val Rank.ordinal: Int
    get() = when (this) {
        Rank.ACE -> 0
        Rank.TWO -> 1
        Rank.THREE -> 2
        Rank.FOUR -> 3
        Rank.FIVE -> 4
        Rank.SIX -> 5
        Rank.SEVEN -> 6
        Rank.EIGHT -> 7
        Rank.NINE -> 8
        Rank.TEN -> 9
        Rank.JACK -> 10
        Rank.QUEEN -> 11
        Rank.KING -> 12
    }