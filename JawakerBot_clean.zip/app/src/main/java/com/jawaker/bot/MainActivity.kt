package com.jawaker.bot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var mFloatingView: View? = null
    private var mParams: WindowManager.LayoutParams? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if SYSTEM_ALERT_WINDOW permission is granted
        if (!hasSystemAlertWindowPermission()) {
            requestSystemAlertWindowPermission()
            return
        }

        // Inflate the floating overlay layout
        val inflater = LayoutInflater.from(this)
        mFloatingView = inflater.inflate(R.layout.overlay_bot, null)

        mParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )

        mParams!!.gravity = Gravity.BOTTOM
        mParams!!.x = 0f
        mParams!!.y = 0f
        mParams!!.width = WindowManager.LayoutParams.MATCH_PARENT
        mParams!!.height = WindowManager.LayoutParams.WRAP_CONTENT
        mParams!!.windowAnimations = 0

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.addView(mFloatingView, mParams)
    }

    private fun hasSystemAlertWindowPermission(): Boolean {
        return android.provider.Settings.canDrawOverlays(this)
    }

    private fun requestSystemAlertWindowPermission() {
        val intent = android.provider.Settings
            .actionMANAGE_OVERLAY_PERMISSION
            android.data = android.net.Uri.parse("package:" + packageName)
        startActivityForResult(intent, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            // Permission granted, restart the activity
            if (hasSystemAlertWindowPermission()) {
                recreate()
            }
        }
    }
}