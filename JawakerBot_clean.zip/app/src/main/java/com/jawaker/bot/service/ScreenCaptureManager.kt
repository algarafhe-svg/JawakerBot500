package com.jawaker.bot.service

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Bitmap.Config
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.util.Log
import androidx.annotation.NonNull
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer

class ScreenCaptureManager(private val activity: Activity) {

    private var mImageReader: ImageReader? = null
    private var mTextRecognizer: TextRecognizer? = null
    private lateinit val onBitmapReady: (Bitmap) -> Unit

    init {
        mTextRecognizer = TextRecognition.getClient(TextRecognizer.DEFAULT_OPTIONS)
    }

    fun calibrate() {
        // Calculate screen regions based on device display
        val display = activity.windowManager.defaultDisplay
        // Calibration logic will be implemented based on screen dimensions
    }

    /**
     * Capture the screen using MediaProjection
     */
    fun captureScreen(): Bitmap? {
        val screenWidth = activity.windowManager.defaultDisplay.width
        val screenHeight = activity.windowManager.defaultDisplay.height

        // Set up ImageReader for screen capture
        mImageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            Bitmap.Config.ARGB_8888,
            1
        )

        val handler = Handler(activity.mainLooper)
        val imageReaderListener = object : ImageReader.OnImageAvailableListener {
            override fun onImageAvailable(reader: ImageReader): Unit {
                val image: Image? = reader.acquireLatestImage()
                if (image != null) {
                    try {
                        val buffer = image.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining())
                        buffer.get(bytes)
                        // CRITICAL: Create bitmap with correct dimensions matching screen
                        val bitmap = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888)
                        // Copy pixel data from Image to Bitmap
                        val pixel = android.graphics.Point()
                        for (y in 0 until screenHeight) {
                            for (x in 0 until screenWidth) {
                                image.getPixel(x, y, pixel)
                                bitmap.setPixel(x, y, pixel.r, pixel.g, pixel.b, pixel.a)
                            }
                        }
                        onBitmapReady(bitmap)
                    } catch (e: Exception) {
                        Log.e("ScreenCapture", "Error converting image", e)
                    } finally {
                        image.close()
                    }
                }
            }
        }

        mImageReader?.setOnImageAvailableListener(imageReaderListener, handler)

        // Return placeholder bitmap
        return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    }

    /**
     * Analyze the captured screen to identify game state
     * CRITICAL: Accepts screen dimensions for coordinate scaling correction
     */
    fun analyzeScreen(bitmap: Bitmap, screenWidth: Int, screenHeight: Int): GameState {
        val gameState = GameState()

        // Extract card information using hybrid approach: ML Kit OCR + pixel color analysis
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        val task = mTextRecognizer?.process(inputImage)
        task?.addOnSuccessListener { text ->
            processTextRecognition(text, gameState)
        }.addOnFailureListener { e ->
            Log.e("ScreenCapture", "ML Kit OCR failed", e)
            // Fallback: pixel color analysis with scaling correction
            analyzeByPixelColor(bitmap, gameState, screenWidth, screenHeight)
        }

        return gameState
    }

    private fun processTextRecognition(text: Text, gameState: GameState) {
        val recognizedText = text.getText()
        val lines = recognizedText.split("\n")

        for (line in lines) {
            // Extract card values and suits
            val value = extractCardValue(line)
            val suit = extractCardSuit(line)

            if (value != null && suit != null) {
                gameState.addDiscoveredCard(value, suit)
            }
        }

        // If ML Kit fails to detect, fall back to pixel color analysis
        if (gameState.discoveredCards.isEmpty()) {
            // We need screenWidth/screenHeight here - use defaults if not available
            val sw = 360 // default fallback
            val sh = 640 // default fallback
            analyzeByPixelColor(bitmap, gameState, sw, sh)
        }
    }

    private fun extractCardValue(text: String): String? {
        // Look for card values: A, 2-10, J, Q, K
        val upperText = text.uppercase()
        return when {
            upperText.contains("A") -> "A"
            upperText.contains("J") -> "J"
            upperText.contains("Q") -> "Q"
            upperText.contains("K") -> "K"
            upperText.contains("2") -> "2"
            upperText.contains("3") -> "3"
            upperText.contains("4") -> "4"
            upperText.contains("5") -> "5"
            upperText.contains("6") -> "6"
            upperText.contains("7") -> "7"
            upperText.contains("8") -> "8"
            upperText.contains("9") -> "9"
            upperText.contains("10") -> "10"
            null -> null
        }
    }

    private fun extractCardSuit(text: String): String? {
        // Look for card suits: ♥ ♦ ♠ ♣
        when {
            text.contains("♥") -> "♥"
            text.contains("♦") -> "♦"
            text.contains("♠") -> "♠"
            text.contains("♣") -> "♣"
            null -> null
        }
    }

    /**
     * Analyze pixel colors with screen coordinate scaling correction.
     * Ensures detected card positions map 1:1 to actual screen coordinates.
     */
    private fun analyzeByPixelColor(bitmap: Bitmap, gameState: GameState, screenWidth: Int, screenHeight: Int) {
        val bitmapWidth = bitmap.width
        val bitmapHeight = bitmap.height

        // Calculate scaling factors from bitmap to screen
        val scaleX = if (bitmapWidth > 0) screenWidth.toFloat() / bitmapWidth else 1f
        val scaleY = if (bitmapHeight > 0) screenHeight.toFloat() / bitmapHeight else 1f

        // Analyze pixel colors in regions corresponding to Jawaker layout
        // Use scaled coordinates to match actual screen positions

        // 1. Check Stock Pile region (top-right: ~87% width, 22% height)
        val stockScreenX = (0.87f * screenWidth).toInt()
        val stockScreenY = (0.22f * screenHeight).toInt()
        val stockBitmapX = (stockScreenX * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
        val stockBitmapY = (stockScreenY * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)

        // Sample pixels around stock pile area
        val stockSampleRegion = Rect(
            stockBitmapX - 20,
            stockBitmapY - 20,
            stockBitmapX + 20,
            stockBitmapY + 20
        ).apply {
            left = Math.max(0, left)
            right = Math.min(bitmapWidth, right)
            top = Math.max(0, top)
            bottom = Math.min(bitmapHeight, bottom)
        }

        // Analyze this region for card indicators
        analyzeRegionForCards(bitmap, stockSampleRegion, gameState, "stock")

        // 2. Check Waste Pile region (X=62%-78%, Y=22%)
        val wasteLeftScreen = (0.62f * screenWidth).toInt()
        val wasteRightScreen = (0.78f * screenWidth).toInt()
        val wasteTopScreen = (0.22f * screenHeight).toInt()
        val wasteBottomScreen = wasteTopScreen + (screenHeight / 6).toInt()

        val wasteLeftBitmap = (wasteLeftScreen * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
        val wasteRightBitmap = (wasteRightScreen * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
        val wasteTopBitmap = (wasteTopScreen * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)
        val wasteBottomBitmap = (wasteBottomScreen * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)

        val wasteRegion = Rect(wasteLeftBitmap, wasteTopBitmap, wasteRightBitmap, wasteBottomBitmap)
        analyzeRegionForCards(bitmap, wasteRegion, gameState, "waste")

        // 3. Check Foundations region (X=12%-55%, Y=22%)
        val foundationsLeftScreen = (0.12f * screenWidth).toInt()
        val foundationsRightScreen = (0.55f * screenWidth).toInt()
        val foundationsTopScreen = (0.22f * screenHeight).toInt()
        val foundationsBottomScreen = foundationsTopScreen + (screenHeight / 8).toInt()

        val foundationsLeftBitmap = (foundationsLeftScreen * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
        val foundationsRightBitmap = (foundationsRightScreen * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
        val foundationsTopBitmap = (foundationsTopScreen * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)
        val foundationsBottomBitmap = (foundationsBottomScreen * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)

        val foundationsRegion = Rect(foundationsLeftBitmap, foundationsTopBitmap, foundationsRightBitmap, foundationsBottomBitmap)
        analyzeRegionForCards(bitmap, foundationsRegion, gameState, "foundations")

        // 4. Check Tableau Columns (7 columns, start at Y=33%)
        val tableauStartYScreen = (0.33f * screenHeight).toInt()
        val columnWidthScreen = (screenWidth / 7).toInt()

        for (colIndex in 0 until 7) {
            val colCenterXScreen = (colIndex * columnWidthScreen + columnWidthScreen / 2).coerceAtLeast(0).coerceAtMost(screenWidth - 1)
            val colCenterXBitmap = (colCenterXScreen * bitmapWidth / screenWidth).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
            val colCenterYScreen = tableauStartYScreen + (screenHeight / 6).toInt()
            val colCenterYBitmap = (colCenterYScreen * bitmapHeight / screenHeight).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)

            // Each column has a region
            val colLeftBitmap = (colCenterXBitmap - 30).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
            val colRightBitmap = (colCenterXBitmap + 30).coerceAtLeast(0).coerceAtMost(bitmapWidth - 1)
            val colTopBitmap = (colCenterYBitmap - 40).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)
            val colBottomBitmap = (colCenterYBitmap + 40).coerceAtLeast(0).coerceAtMost(bitmapHeight - 1)

            val columnRegion = Rect(colLeftBitmap, colTopBitmap, colRightBitmap, colBottomBitmap)
            analyzeRegionForCards(bitmap, columnRegion, gameState, "tableau_$colIndex")
        }
    }

    /**
     * Analyze a region of the bitmap for card color/suit indicators.
     * Applies scaling corrections and classifies detected suit colors.
     */
    private fun analyzeRegionForCards(
        bitmap: Bitmap,
        region: Rect,
        gameState: GameState,
        regionName: String
    ) {
        val width = region.width()
        val height = region.height()

        if (width <= 0 || height <= 0) {
            Log.d("ScreenCapture", "Skipping $regionName: invalid region dimensions $width x $height")
            return
        }

        // Sample pixels across the region using scaled grid
        val sampleStep = maxOf(1, min(width, height) / 8)

        var redCount = 0
        var blueCount = 0
        var blackCount = 0

        // Track center of sampled region for debugging
        val centerX = region.left + width / 2
        val centerY = region.top + height / 2

        Log.d("ScreenCapture", "Analyzing $regionName at bitmap coords($centerX, $centerY), step=$sampleStep")

        for (x in region.left until region.right step sampleStep) {
            for (y in region.top until region.bottom step sampleStep) {
                // Ensure within bounds
                val sx = Math.min(bitmap.width - 1, x)
                val sy = Math.min(bitmap.height - 1, y)

                val pixel = bitmap.getPixel(sx, sy)
                val r = (pixel and 0x00FF0000) >> 16
                val g = (pixel and 0x0000FF00) >> 8
                val b = pixel and 0x000000FF

                // Color classification for suits
                // Hearts/Diamonds: high red, low green/blue
                // Spades/Clubs: high blue/black, low red

                if (r > 150 && g < 100 && b < 100) {
                    // Red region - likely Hearts or Diamonds
                    redCount++
                } else if (r < 100 && b > 150 && g < 100) {
                    // Blue region - likely Spades
                    blueCount++
                } else if (r < 50 && b > 150 && g < 50) {
                    // Dark blue/black - likely Clubs
                    blackCount++
                }
            }
        }

        // Determine dominant suit color in this region
        val dominantColor = when {
            redCount > blueCount + blackCount && redCount > 5 -> "red"   // Hearts or Diamonds
            blueCount > blackCount && blueCount > 5 -> "black"          // Spades or Clubs
            else -> "unknown"
        }

        Log.d("ScreenCapture", "$regionName: red=$redCount, blue=$blueCount, black=$blackCount -> dominant=$dominantColor")

        // Store detection info - in full implementation would create Card objects
        // For now, just log the detection
    }

    /**
     * Game state container holding all detected game elements
     */
    data class GameState(
        /** Cards in the stock pile (left side, top) */
        var stockPileCards: List<Card> = emptyList(),
        /** Top card visible in waste pile (above tableau, left of stock) */
        var wastePileTopCard: Card? = null,
        /** Foundation piles - 4 slots top-right area */
        var foundationPiles: List<FoundationSlot> = emptyList(),
        /** Tableau columns - 7 columns starting at Y=33% */
        var tableauColumns: List<TableauColumn> = emptyList()
    )

    data class FoundationSlot(
        /** The suit of this foundation pile (inferred from position/order) */
        var suit: Suit? = null,
        /** Cards added to this pile, top is last */
        var cards: List<Card> = emptyList()
    )

    data class TableauColumn(
        /** The column index (1-7) */
        var columnIndex: Int = 1,
        /** Cards in this column from bottom to top */
        var cards: List<Card> = emptyList(),
        /** The top-most visible card position (X, Y coordinates) */
        var topCardPosition: Pair<Float, Float> = Pair(0f, 0f)
    )