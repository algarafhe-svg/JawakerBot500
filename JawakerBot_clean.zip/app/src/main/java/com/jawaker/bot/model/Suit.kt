package com.jawaker.bot.model

/**
 * Enum representing card suits with color information.
 */
enum class Suit(
    /** Hearts - red suit */
    HEART,
    /** Diamonds - red suit */
    DIAMOND,
    /** Spades - black suit */
    SPADE,
    /** Clubs - black suit */
    CLUB
) {
    /** Get the color of this suit - "red" or "black" */
    val color: String
        get() = when (this) {
            Suit.HEART, Suit.DIAMOND -> "red"
            Suit.SPADE, Suit.CLUB -> "black"
        }

        /** Get the Unicode symbol for this suit */
        val symbol: String
            get() = when (this) {
                Suit.HEART -> "♥"
                Suit.DIAMOND -> "♦"
                Suit.SPADE -> "♠"
                Suit.CLUB -> "♣"
            }
}