package com.jawaker.bot

import com.jawaker.bot.model.Card
import com.jawaker.bot.model.Rank
import com.jawaker.bot.model.Suit

/**
 * The main auto-solver that determines the best move based on game state.
 * Implements all priority rules for Jawaker/Solitaire gameplay.
 * Rules ordered by priority (1 = highest priority).
 */
class JawakerAutoSolver {

    private lateinit var cardVisionEngine: CardVisionEngine

    init {
        cardVisionEngine = CardVisionEngine()
    }

    /**
     * Determine the next move based on current game state.
     * Returns null if no valid move is found.
     */
    fun decideNextMove(gameState: CardVisionEngine.GameState): BotMove? {
        // Priority 1: Move Aces and Twos to foundations immediately
        val aceOrTwoMove = checkForAceOrTwoMove(gameState)
        if (aceOrTwoMove != null) return aceOrTwoMove

        // Priority 2: Check for valid tableau moves (sub-stack moving)
        val tableauMove = checkTableauMove(gameState)
        if (tableauMove != null) return tableauMove

        // Priority 3: Check foundation moves (Kings to empty columns, safe moves)
        val foundationMove = checkFoundationMoves(gameState)
        if (foundationMove != null) return foundationMove

        // Priority 4: Check waste pile moves
        val wasteMove = checkWasteMoves(gameState)
        if (wasteMove != null) return wasteMove

        // Priority 5: Recycle stock if no moves available
        return checkStockRecycle(gameState)
    }

    /**
     * Rule 1: If any Ace (A) or Two (2) appears, move it immediately to foundations.
     * Priority highest - as soon as A or 2 is visible anywhere, move to foundations.
     */
    private fun checkForAceOrTwoMove(gameState: CardVisionEngine.GameState): BotMove? {
        // Check all discovered cards for Aces and Twos
        for (card in gameState.discoveredCards) {
            when (card.rank) {
                Rank.ACE -> {
                    // Try to move to any foundation
                    return BotMove(
                        BotMove.Type.FOUNDATION,
                        card,
                        null,
                        "Move Ace ${card.suit} to foundation"
                    )
                }
                Rank.TWO -> {
                    return BotMove(
                        BotMove.Type.FOUNDATION,
                        card,
                        null,
                        "Move Two ${card.suit} to foundation"
                    )
                }
            }
        }

        // Also check tableau cards for Aces and Twos that can be moved
        for (column in gameState.tableauColumns) {
            for (card in column.cards) {
                when (card.rank) {
                    Rank.ACE, Rank.TWO -> {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move ${card.rank}${card.suit} from tableau to foundation"
                        )
                    }
                }
            }
        }

        // Check waste pile top card
        if (gameState.wastePileTopCard != null) {
            val wasteCard = gameState.wastePileTopCard!!
            when (wasteCard.rank) {
                Rank.ACE, Rank.TWO -> {
                    return BotMove(
                        BotMove.Type.FOUNDATION,
                        wasteCard,
                        null,
                        "Move ${wasteCard.rank}${wasteCard.suit} from waste to foundation"
                    )
                }
            }
        }

        return null
    }

    /**
     * Rule 2: Sub-stack moving between tableau columns.
     * Move descending sequences of alternating colors.
     * Ability to detect descending sequence of alternating colors within any column,
     * and calculate coordinates to move the stack as a single unit.
     */
    private fun checkTableauMove(gameState: CardVisionEngine.GameState): BotMove? {
        // For each source column
        for (sourceColIndex in gameState.tableauColumns.indices) {
            val sourceCol = gameState.tableauColumns[sourceColIndex]

            // Find descending sequences with alternating colors
            val sequences = findDescendingSequences(sourceCol)

            for (sequence in sequences) {
                if (sequence.cards.size < 2) continue

                // Get the target column that can accept this sequence
                val targetCol = findTargetColumnForSequence(gameState, sourceCol, sequence)

                if (targetCol != null) {
                    val startX = sequence.startPosition.first
                    val startY = sequence.startPosition.second
                    val endX = targetCol.topCardPosition.first
                    val endY = targetCol.topCardPosition.second

                    return BotMove(
                        BotMove.Type.TABLEAU,
                        sequence.firstCard,
                        sequence.lastCard,
                        "Move stack of ${sequence.cards.size} cards from column ${sourceCol.columnIndex} to column ${targetCol.columnIndex}",
                        startX, startY, endX, endY
                    )
                }
            }
        }

        return null
    }

    /**
     * Find descending sequences with alternating colors in a tableau column.
     * A descending sequence means each card is one rank lower than the previous,
     * and alternating colors (red/black) between consecutive cards.
     */
    private fun findDescendingSequences(column: CardVisionEngine.GameState.TableauColumn): List<SequenceInfo> {
        val sequences = mutableListOf<SequenceInfo>()
        var currentSequence = mutableListOf<Card>()

        for (i in column.cards.indices) {
            val card = column.cards[i]

            if (i == 0) {
                currentSequence.add(card)
            } else {
                val previousCard = column.cards[i - 1]

                // Check if card is one rank lower than previous
                val isDescending = card.rank.ordinal - previousCard.rank.ordinal == 1
                // Check if colors alternate (red/black)
                val isAlternatingColor = card.suit.color != previousCard.suit.color

                if (isDescending && isAlternatingColor) {
                    currentSequence.add(card)
                } else {
                    // Save current sequence if it has at least 2 cards
                    if (currentSequence.size >= 2) {
                        sequences.add(SequenceInfo(
                            currentSequence.first(),
                            currentSequence.last(),
                            currentSequence,
                            calculateStartPosition(currentSequence, column)
                        ))
                    }
                    currentSequence = mutableListOf<Card>()
                    currentSequence.add(card)
                }
            }
        }

        // Save the last sequence
        if (currentSequence.size >= 2) {
            sequences.add(SequenceInfo(
                currentSequence.first(),
                currentSequence.last(),
                currentSequence,
                calculateStartPosition(currentSequence, column)
            ))
        }

        return sequences
    }

    private fun calculateStartPosition(cards: List<Card>, column: CardVisionEngine.GameState.TableauColumn): Pair<Float, Float> {
        // Calculate the position of the first card in the sequence
        // Use the column's X position and the card's Y position
        return Pair(column.topCardPosition.first, column.topCardPosition.second)
    }

    /**
     * Find a valid target column for a sequence following solitaire rules.
     * Target must accept the sequence's first card (one rank lower, alternating color)
     * and must not create an infinite loop situation.
     */
    private fun findTargetColumnForSequence(
        gameState: CardVisionEngine.GameState,
        sourceCol: CardVisionEngine.GameState.TableauColumn,
        sequence: SequenceInfo
    ): CardVisionEngine.GameState.TableauColumn? {
        val targetColor = sourceCol.cards.first().suit.color

        return gameState.tableauColumns.find { targetCol ->
            // Target must accept the sequence's first card
            canAcceptCard(targetCol, sequence.firstCard) &&
                // Check that moving won't create infinite loops
                !willCreateInfiniteLoop(gameState, targetCol, sequence)
        }
    }

    private fun canAcceptCard(column: CardVisionEngine.GameState.TableauColumn, card: Card): Boolean {
        if (column.cards.isEmpty()) {
            // Empty column can only accept King or K-starting sequences
            return card.rank == Rank.KING
        }

        val topCard = column.cards.last()
        // Card must be one rank lower and alternate color
        val isOneRankLower = card.rank.ordinal - topCard.rank.ordinal == 1
        val isAlternatingColor = card.suit.color != topCard.suit.color

        return isOneRankLower && isAlternatingColor
    }

    private fun willCreateInfiniteLoop(
        gameState: CardVisionEngine.GameState,
        targetCol: CardVisionEngine.GameState.TableauColumn,
        sequence: SequenceInfo
    ): Boolean {
        // Simple check: if moving this sequence would just allow the same
        // sequence to be moved back, it's potentially an infinite loop
        // Full implementation would track move history to prevent this
        false
    }

    /**
     * Rule 3: Check foundation moves - Kings to empty columns, safe moves to foundations.
     * Also check for Kings that can go to empty tableau columns.
     */
    private fun checkFoundationMoves(gameState: CardVisionEngine.GameState): BotMove? {
        // First, check for Kings that can go to empty columns
        for (column in gameState.tableauColumns) {
            if (column.cards.isEmpty()) {
                // Look for Kings in discovered cards or tableau
                for (card in gameState.discoveredCards) {
                    if (card.rank == Rank.KING) {
                        return BotMove(
                            BotMove.Type.TABLEAU,
                            card,
                            null,
                            "Move King ${card.suit} to empty column",
                            0f, 0f, 0f, 0f // coords will be determined by accessibility service
                        )
                    }
                }
                // Also check tableau columns for Kings
                for (tableauCard in column.cards) {
                    if (tableauCard.rank == Rank.KING) {
                        return BotMove(
                            BotMove.Type.TABLEAU,
                            tableauCard,
                            null,
                            "Move King ${tableauCard.suit} from column ${column.columnIndex} to empty column"
                        )
                    }
                }
            }
        }

        // Check for safe foundation moves (3-K of same suit)
        // Priority: move cards to foundations if it helps the game state
        for (card in gameState.discoveredCards) {
            when (card.rank) {
                Rank.THREE, Rank.FOUR, Rank.FIVE, Rank.SIX,
                    Rank.SEVEN, Rank.EIGHT, Rank.NINE, Rank.TEN,
                    Rank.JACK, Rank.QUEEN, Rank.KING -> {
                    // Check if this card can go to foundation
                    // Foundations are built Ace to King by suit
                    val suitableFoundation = gameState.foundationPiles.find { foundation ->
                        // Foundation must either be empty (waiting for Ace) or have top card
                        // that is one rank lower and same suit
                        if (foundation.cards.isEmpty()) {
                            // Empty foundation needs Ace - skip non-Ace cards
                            false
                        } else {
                            val topCard = foundation.cards.last()
                            // Must be next rank up and same suit
                            val isNextRank = card.rank.ordinal - topCard.rank.ordinal == 1
                            val isSameSuit = card.suit == foundation.suit

                            isNextRank && isSameSuit
                        }
                    }

                    if (suitableFoundation != null) {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move ${card.rank}${card.suit} to foundation"
                        )
                    }
                }
            }
        }

        // Also check waste pile top card for foundation moves
        if (gameState.wastePileTopCard != null) {
            val wasteCard = gameState.wastePileTopCard!!
            when (wasteCard.rank) {
                Rank.THREE, Rank.FOUR, Rank.FIVE, Rank.SIX,
                    Rank.SEVEN, Rank.EIGHT, Rank.NINE, Rank.TEN,
                    Rank.JACK, Rank.QUEEN, Rank.KING -> {
                    val suitableFoundation = gameState.foundationPiles.find { foundation ->
                        if (foundation.cards.isEmpty()) false
                        else {
                            val topCard = foundation.cards.last()
                            val isNextRank = wasteCard.rank.ordinal - topCard.rank.ordinal == 1
                            val isSameSuit = wasteCard.suit == foundation.suit
                            isNextRank && isSameSuit
                        }
                    }

                    if (suitableFoundation != null) {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            wasteCard,
                            null,
                            "Move ${wasteCard.rank}${wasteCard.suit} from waste to foundation"
                        )
                    }
                }
            }
        }

        return null
    }

    /**
     * Rule 4: Check waste pile moves.
     * Evaluate waste pile top card for valid moves to foundations or tableau.
     */
    private fun checkWasteMoves(gameState: CardVisionEngine.GameState): BotMove? {
        val wasteTop = gameState.wastePileTopCard

        if (wasteTop == null) return null

        // Check if waste top card can go to foundation
        val foundationMove = checkFoundationCardMove(wasteTop, gameState)
        if (foundationMove != null) return foundationMove

        // Check if waste top card can go to tableau
        val tableauMove = checkTableauCardMove(wasteTop, gameState)
        if (tableauMove != null) return tableauMove

        return null
    }

    private fun checkFoundationCardMove(card: Card, gameState: CardVisionEngine.GameState): BotMove? {
        val suitableFoundation = gameState.foundationPiles.find { foundation ->
            if (foundation.cards.isEmpty()) false
            else {
                val topCard = foundation.cards.last()
                val isNextRank = card.rank.ordinal - topCard.rank.ordinal == 1
                val isSameSuit = card.suit == foundation.suit

                isNextRank && isSameSuit
            }
        }

        return if (suitableFoundation != null) {
            BotMove(
                BotMove.Type.FOUNDATION,
                card,
                null,
                "Move ${card.rank}${card.suit} from waste to foundation"
            )
        } else null
    }

    private fun checkTableauCardMove(card: Card, gameState: CardVisionEngine.GameState): BotMove? {
        // Try each tableau column
        for (columnIndex in gameState.tableauColumns.indices) {
            val targetCol = gameState.tableauColumns[columnIndex]

            if (canPlaceOnTableau(card, targetCol)) {
                // Determine start coordinates from waste pile area
                val startX = 65f // Waste pile X area (62-78% range)
                val startY = 22f // Waste pile Y (22% from top)
                val endX = targetCol.topCardPosition.first
                val endY = targetCol.topCardPosition.second

                return BotMove(
                    BotMove.Type.TABLEAU,
                    card,
                    null,
                    "Move ${card.rank}${card.suit} from waste to column ${targetCol.columnIndex}",
                    startX, startY, endX, endY
                )
            }
        }

        return null
    }

    private fun canPlaceOnTableau(card: Card, column: CardVisionEngine.GameState.TableauColumn): Boolean {
        if (column.cards.isEmpty()) {
            // Empty column accepts only King
            return card.rank == Rank.KING
        }

        val topCard = column.cards.last()
        // Card must be one rank lower and alternate color
        val isOneRankLower = card.rank.ordinal - topCard.rank.ordinal == 1
        val isAlternatingColor = card.suit.color != topCard.suit.color

        return isOneRankLower && isAlternatingColor
    }

    /**
     * Rule 5: Stock recycle - tap the stock pile when no moves available.
     * Tap stock pile to draw 3 cards, and when deck recycles, tap again.
     */
    private fun checkStockRecycle(gameState: CardVisionEngine.GameState): BotMove? {
        // This is a special move type - just tapping the stock pile
        // Stock pile located at top-right (87% from left, 22% from top)
        return BotMove(
            BotMove.Type.STOCK_TAP,
            null,
            null,
            "Tap stock pile to draw 3 cards"
        )
    }
}

/**
 * Helper data class for storing sequence information during tableau move detection.
 */
data class SequenceInfo(
    val firstCard: Card,
    val lastCard: Card,
    val cards: List<Card>,
    val startPosition: Pair<Float, Float>
)