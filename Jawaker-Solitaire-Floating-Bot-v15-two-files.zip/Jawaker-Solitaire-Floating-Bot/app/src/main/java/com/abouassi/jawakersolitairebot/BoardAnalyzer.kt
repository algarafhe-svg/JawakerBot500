package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.media.Image
import kotlin.math.abs
import java.util.ArrayDeque

/** Reads the current board and returns one legal tableau/waste move or a stock tap. */
object BoardAnalyzer {
    data class Move(
        val fromX: Float,
        val fromY: Float,
        val toX: Float,
        val toY: Float,
        val durationMs: Long = 770L,
        val isTap: Boolean = false,
        val isDoubleTap: Boolean = false
    )

    data class Analysis(val status: String, val proposedMove: Move? = null)

    private const val REF_W = 720f
    private const val REF_H = 1640f
    private const val WASTE_X = 565f
    private const val WASTE_Y = 490f
    private const val DEFAULT_DRAG_MS = 770L
    private const val MOVE_HISTORY_LIMIT = 60
    private const val TABLEAU_MIN_Y = 580f
    private const val TABLEAU_MAX_Y = 1250f
    private const val EMPTY_COLUMN_DROP_Y = 620f
    private val recentMoveKeys = ArrayDeque<String>()
    private val recentMoveSet = mutableSetOf<String>()
    private var stockDrawCount = 0
    private const val MAX_STOCK_DRAWS_WITHOUT_MOVE = 24

    fun analyze(image: Image, width: Int, height: Int): Analysis {
        val bitmap = try { CardVision.imageToBitmap(image) }
        catch (_: Exception) { return Analysis("تعذر تحويل لقطة الشاشة") }
        return try { analyze(bitmap) } finally { bitmap.recycle() }
    }

    fun analyze(bitmap: Bitmap): Analysis {
        val board = try { CardVision.analyze(bitmap) }
        catch (e: Exception) {
            return Analysis("خطأ قراءة اللوحة: ${e.message ?: "غير معروف"}")
        }
        val sx = bitmap.width / REF_W
        val sy = bitmap.height / REF_H
        val cols = board.columns
        if (cols.size != 7) return Analysis("لم أتعرف على الأعمدة السبعة. ${board.diagnostics}")
        val detectedTableauCards = cols.sumOf { it.visibleCards.size }
        if (detectedTableauCards == 0 && board.waste == null) {
            return Analysis("قرار: لم أتعرف على كروت الأعمدة أو الكومة؛ ${board.diagnostics}")
        }

        data class Candidate(val move: Move, val score: Int, val label: String)
        val foundationCandidates = mutableListOf<Candidate>()
        val tableauCandidates = mutableListOf<Candidate>()
        val wasteCandidates = mutableListOf<Candidate>()

        // Priority 1: exposed tableau cards to foundation, only when exact suit is known.
        for (from in cols.indices) {
            val card = cols[from].visibleCards.lastOrNull() ?: continue
            val suit = card.suit ?: continue
            val current = board.foundationRanks[suit] ?: 0
            if (SolitaireEngine.canMoveToFoundation(card.rank, current)) {
                val tapX = CardVisionCenter.column(from) * sx
                val tapY = (card.topY + 42f * sy).coerceIn(TABLEAU_MIN_Y * sy, TABLEAU_MAX_Y * sy)
                foundationCandidates += Candidate(
                    Move(tapX, tapY, tapX, tapY, 55L, isDoubleTap = true),
                    500,
                    "رفع ${rankName(card.rank)}${suitSymbol(suit)} من العمود ${from + 1} إلى الأساس بالنقر المزدوج"
                )
            }
        }
        board.waste?.let { card ->
            val suit = card.suit
            if (suit != null) {
                val current = board.foundationRanks[suit] ?: 0
                if (SolitaireEngine.canMoveToFoundation(card.rank, current)) {
                    foundationCandidates += Candidate(
                        Move(WASTE_X * sx, WASTE_Y * sy, WASTE_X * sx, WASTE_Y * sy, 55L, isDoubleTap = true),
                        490,
                        "رفع ${rankName(card.rank)}${suitSymbol(suit)} من المخلفات إلى الأساس بالنقر المزدوج"
                    )
                }
            }
        }
        val bestFoundation = foundationCandidates.firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestFoundation != null) {
            rememberMove(bestFoundation.move)
            stockDrawCount = 0
            return Analysis("قرار: ${bestFoundation.label}؛ ${board.diagnostics}", bestFoundation.move)
        }

        // Priority 2: move a valid descending alternating-colour suffix between tableau columns.
        for (from in cols.indices) {
            val source = cols[from].visibleCards
            if (source.isEmpty()) continue
            for (start in source.indices) {
                val suffix = source.drop(start)
                if (!isValidSequence(suffix)) continue
                val moving = suffix.first()
                for (to in cols.indices) {
                    if (to == from) continue
                    val targetCards = cols[to].visibleCards
                    val target = targetCards.lastOrNull()
                    val targetIsCompletelyEmpty = targetCards.isEmpty() && cols[to].hiddenCount == 0
                    val legal = SolitaireEngine.canStackOnTableau(
                        moving.rank, moving.suitColor, target?.rank, target?.suitColor, targetIsCompletelyEmpty
                    )
                    if (!legal) continue

                    val sourceX = CardVisionCenter.column(from) * sx
                    val targetX = CardVisionCenter.column(to) * sx
                    val sourceY = (moving.topY + 24f * sy).coerceIn(TABLEAU_MIN_Y * sy, TABLEAU_MAX_Y * sy)
                    val targetY = if (targetIsCompletelyEmpty) EMPTY_COLUMN_DROP_Y * sy
                        else (target!!.topY + 42f * sy).coerceIn(TABLEAU_MIN_Y * sy, TABLEAU_MAX_Y * sy)

                    val revealBonus = if (start == 0 && cols[from].hiddenCount > 0) 35 else 0
                    val score = 300 + revealBonus + if (targetIsCompletelyEmpty) 5 else 0
                    tableauCandidates += Candidate(
                        Move(sourceX, sourceY, targetX, targetY, DEFAULT_DRAG_MS),
                        score,
                        "${rankName(moving.rank)} من العمود ${from + 1} إلى ${to + 1}"
                    )
                }
            }
        }

        // Priority 3: The free waste card (Draw-3 rightmost) can be placed on a legal tableau column.
        board.waste?.let { waste ->
            for (to in cols.indices) {
                val target = cols[to].visibleCards.lastOrNull()
                val targetIsCompletelyEmpty = board.columns[to].visibleCards.isEmpty() &&
                    board.columns[to].hiddenCount == 0
                val legal = SolitaireEngine.canStackOnTableau(
                    waste.rank, waste.suitColor, target?.rank, target?.suitColor, targetIsCompletelyEmpty
                )
                if (legal) {
                    val targetY = if (targetIsCompletelyEmpty) EMPTY_COLUMN_DROP_Y * sy
                        else (target!!.topY + 42f * sy).coerceIn(TABLEAU_MIN_Y * sy, TABLEAU_MAX_Y * sy)
                    wasteCandidates += Candidate(
                        Move(WASTE_X * sx, WASTE_Y * sy, CardVisionCenter.column(to) * sx, targetY, DEFAULT_DRAG_MS),
                        200,
                        "نقل ${rankName(waste.rank)} من المخلفات إلى العمود ${to + 1}"
                    )
                }
            }
        }

        val bestTableau = tableauCandidates.sortedByDescending { it.score }
            .firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestTableau != null) {
            rememberMove(bestTableau.move)
            stockDrawCount = 0
            return Analysis("قرار: ${bestTableau.label}", bestTableau.move)
        }

        val bestWaste = wasteCandidates.sortedByDescending { it.score }
            .firstOrNull { !isRecentlyRepeated(it.move) }
        if (bestWaste != null) {
            rememberMove(bestWaste.move)
            stockDrawCount = 0
            return Analysis("قرار: ${bestWaste.label}", bestWaste.move)
        }

        // Priority 4: draw only after all foundation/tableau/waste moves are exhausted.
        if (board.stockHasCard && stockDrawCount < MAX_STOCK_DRAWS_WITHOUT_MOVE) {
            val stockX = 655f * sx
            val stockY = 490f * sy
            stockDrawCount++
            return Analysis(
                "قرار: نقر الكومة (${stockDrawCount}/${MAX_STOCK_DRAWS_WITHOUT_MOVE})؛ ${board.diagnostics}",
                Move(stockX, stockY, stockX, stockY, 90L, isTap = true)
            )
        }
        return Analysis("قرار: لم أجد حركة قانونية أو كرتاً في الكومة؛ ${board.diagnostics}")
    }

    @Synchronized
    private fun moveKey(move: Move): String = listOf(
        move.fromX.toInt(), move.fromY.toInt(), move.toX.toInt(), move.toY.toInt(), move.isTap, move.isDoubleTap
    ).joinToString(":")

    @Synchronized
    private fun isRecentlyRepeated(move: Move): Boolean {
        val reverse = listOf(
            move.toX.toInt(), move.toY.toInt(), move.fromX.toInt(),
            move.fromY.toInt(), move.isTap, move.isDoubleTap
        ).joinToString(":")
        return !move.isTap && !move.isDoubleTap && reverse in recentMoveSet
    }

    @Synchronized
    private fun rememberMove(move: Move) {
        val key = moveKey(move)
        recentMoveKeys.addLast(key)
        recentMoveSet.add(key)
        while (recentMoveKeys.size > MOVE_HISTORY_LIMIT) {
            val old = recentMoveKeys.removeFirst()
            if (old !in recentMoveKeys) recentMoveSet.remove(old)
        }
    }

    private fun isValidSequence(cards: List<CardVision.CardObservation>): Boolean {
        if (cards.isEmpty()) return false
        for (i in 0 until cards.lastIndex) {
            val upper = cards[i]
            val lower = cards[i + 1]
            val verticalGap = abs(lower.topY - upper.topY)
            if (verticalGap > 115f || verticalGap < 16f ||
                upper.suitColor == lower.suitColor || upper.rank != lower.rank + 1
            ) return false
        }
        return true
    }

    private fun rankName(rank: Int): String = when (rank) {
        1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> rank.toString()
    }

    private fun suitSymbol(suit: SolitaireEngine.Suit): String = when (suit) {
        SolitaireEngine.Suit.HEARTS -> "♥"
        SolitaireEngine.Suit.DIAMONDS -> "♦"
        SolitaireEngine.Suit.SPADES -> "♠"
        SolitaireEngine.Suit.CLUBS -> "♣"
    }

    private object CardVisionCenter {
        private val centers = floatArrayOf(68f, 166f, 264f, 362f, 460f, 558f, 655f)
        fun column(index: Int): Float = centers[index.coerceIn(0, 6)]
    }
}
